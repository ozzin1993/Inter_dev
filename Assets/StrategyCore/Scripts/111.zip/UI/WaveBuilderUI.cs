using System;
using System.Collections.Generic;
using UnityEngine;

namespace StrategyCore
{
    /// <summary>
    /// Конструктор состава волны — отдельный компонент (логика волн вынесена из UIManager).
    /// Наборы префабов задаются ПО КОМАНДАМ (у разных команд набор разный). В игре показывается
    /// набор команды локального игрока (UIManager.CommandTeamSlot). На каждый префаб — две кнопки:
    /// «+» (добавить в волну) и «−» (убрать из волны). Каждая кнопка несёт свою команду и юнит-идентификатор
    /// и дёргает штатные MatchManager.TryAddWaveUnit / TryRemoveWaveUnit (серверо-авторитетно).
    /// Кнопки выводятся в нижнюю таблицу UIManager через её публичное API (своей разметки компонент не создаёт).
    /// Все ссылки/наборы/иконки — в Inspector (правило «всё в Inspector»).
    /// </summary>
    public class WaveBuilderUI : MonoBehaviour
    {
        /// <summary>Набор доступных префабов для одной команды.</summary>
        [Serializable]
        public class TeamUnitSet
        {
            [Tooltip("Номер команды (0=A, 1=B), к которой относится этот набор.")]
            public int team;

            [Tooltip("Префабы юнитов, доступных этой команде для добавления в волну.")]
            public Unit[] units;
        }

        [Header("Связи")]
        [Tooltip("UIManager с нижними таблицами — туда выводятся кнопки конструктора.")]
        [SerializeField] UIManager uiManager;

        [Tooltip("Индекс нижней таблицы UIManager под кнопки волны (правая обычно = 2).")]
        [SerializeField] int waveTableIndex = 2;

        [Tooltip("Сколько ячеек в ряду одного юнита (иконка, +, −, цена/кол-во) — задаёт ширину таблицы волны.")]
        [SerializeField] int unitRowColumns = 4;

        [Header("Наборы юнитов по командам")]
        [Tooltip("Для каждой команды свой список префабов. В игре показывается набор команды локального игрока.")]
        [SerializeField] TeamUnitSet[] teamUnitSets;

        [Header("Иконки кнопок")]
        [Tooltip("Иконка кнопки «+» (добавить юнит в волну).")]
        [SerializeField] Texture2D addIcon;

        [Tooltip("Иконка кнопки «−» (убрать юнит из волны).")]
        [SerializeField] Texture2D removeIcon;

        bool wired;   // подписка и первая отрисовка выполнены (таблицы и MatchManager готовы)

        void Start() => TryWire();

        // UIManager и MatchManager могут инициализироваться позже — повторяем, пока не готово.
        void LateUpdate()
        {
            if (!wired) TryWire();
        }

        void OnDestroy()
        {
            if (MatchManager.instance != null)
                MatchManager.instance.OnWaveCompositionChanged -= OnWaveCompositionChanged;
        }

        // Готовимся один раз: ждём готовности нижних таблиц и MatchManager (нужен для цен/количества),
        // подписываемся на изменение состава волны и делаем первую отрисовку.
        void TryWire()
        {
            if (wired) return;
            if (uiManager == null || !uiManager.BottomTablesReady) return;   // ждём готовности таблиц
            if (MatchManager.instance == null) return;                       // нужен для цен и кол-ва

            wired = true;
            MatchManager.instance.OnWaveCompositionChanged += OnWaveCompositionChanged;
            // Таблице волны нужна своя ширина под доп. столбец (иначе ряд переносится).
            uiManager.SetBottomTableColumns(waveTableIndex, unitRowColumns);
            Rebuild();
        }

        // Состав волны изменился — перерисовываем только для своей команды (живое кол-во в ячейке).
        void OnWaveCompositionChanged(int teamIndex)
        {
            if (uiManager != null && teamIndex == uiManager.CommandTeamSlot) Rebuild();
        }

        // Строит кнопки набора локальной команды и кладёт их в нижнюю таблицу UIManager.
        // Ряд юнита: [иконка] [+] [−] [цена/кол-во]. Цена и кол-во — из MatchManager (единый источник).
        void Rebuild()
        {
            if (uiManager == null || !uiManager.BottomTablesReady) return;

            int team = uiManager.CommandTeamSlot;
            Unit[] units = UnitsForTeam(team);
            if (units == null) { uiManager.SetBottomTableElements(waveTableIndex, null); return; } // набор не задан — пусто

            MatchManager mm = MatchManager.instance;

            List<BottomTableButton> buttons = new List<BottomTableButton>();
            for (int i = 0; i < units.Length; i++)
            {
                Unit prefab = units[i];
                if (prefab == null) continue;
                Unit captured = prefab;   // фиксируем для замыканий кнопок

                // Иконка юнита — чтобы видеть, к какому юниту относится ряд (без действия).
                buttons.Add(new BottomTableButton { icon = prefab.icon });
                // «+» и «−»: action несёт команду и юнит-идентификатор → TryAdd/TryRemove.
                buttons.Add(new BottomTableButton { icon = addIcon,    onClick = () => OnWaveButton(team, captured, true) });
                buttons.Add(new BottomTableButton { icon = removeIcon, onClick = () => OnWaveButton(team, captured, false) });
                // Текст: сверху цена «золото / лидерство», снизу текущее кол-во в волне.
                buttons.Add(BuildInfoCell(mm, team, prefab));
            }

            uiManager.SetBottomTableElements(waveTableIndex, buttons);
        }

        // Информационная ячейка: цена (золото / лидерство) сверху, текущее кол-во в волне снизу.
        // Данные — из MatchManager (PrefabResourceCost + WaveUnitCount), без дублирования цен.
        static BottomTableButton BuildInfoCell(MatchManager mm, int team, Unit prefab)
        {
            int gold       = mm != null ? MatchManager.PrefabResourceCost(prefab, mm.GoldResource) : 0;
            int leadership = mm != null ? MatchManager.PrefabResourceCost(prefab, mm.LeadershipResource) : 0;
            int count      = mm != null ? mm.WaveUnitCount(team, prefab) : 0;

            return new BottomTableButton
            {
                topText    = gold + " / " + leadership,
                bottomText = count.ToString(),
                displayOnly = true,
            };
        }

        // Префабы заданной команды (или null, если набор не настроен).
        Unit[] UnitsForTeam(int team)
        {
            if (teamUnitSets == null) return null;
            for (int i = 0; i < teamUnitSets.Length; i++)
                if (teamUnitSets[i] != null && teamUnitSets[i].team == team) return teamUnitSets[i].units;
            return null;
        }

        // Единый action кнопки: команда (0/1) + префаб-идентификатор + направление (добавить/убрать).
        // Хост правит состав напрямую; клиент — через ServerRpc (логика спавна/состава серверо-авторитетна).
        void OnWaveButton(int team, Unit prefab, bool add)
        {
            if (prefab == null) return;

            if (!NetworkConnectionHandler.isClient)
            {
                MatchManager mm = MatchManager.instance;
                if (mm == null) return;
                if (add) mm.TryAddWaveUnit(team, prefab);
                else     mm.TryRemoveWaveUnit(team, prefab);
            }
            else if (NetworkDataSync.instance != null)
            {
                NetworkDataSync.instance.WaveCompositionChangeServerRpc(team, prefab.unitTypeID, add);
            }
        }
    }
}
