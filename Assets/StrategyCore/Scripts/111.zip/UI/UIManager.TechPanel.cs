using System.Linq;
using UnityEngine;
using UnityEngine.UIElements;

namespace StrategyCore
{
    public partial class UIManager : MonoBehaviour
    {
        [Header("Tech Panel")]
        [Tooltip("Технологии для отображения. Если список пуст — показываются все из Resources.")]
        [SerializeField] Technology[] technologies;

        [Tooltip("Сортировать технологии по имени в алфавитном порядке.")]
        [SerializeField] bool sortAlphabetically = true;

        [Tooltip("Показывать уже разблокированные технологии (кнопка будет неактивна).")]
        [SerializeField] bool showUnlocked = true;

        [Tooltip("Суффикс для разблокированных технологий.")]
        [SerializeField] string unlockedLabel = " (Unlocked)";

        [Tooltip("Заголовок панели технологий.")]
        [SerializeField] string panelTitle = "TECHNOLOGIES";

        [Tooltip("Текст кнопки закрытия панели.")]
        [SerializeField] string closeButtonLabel = "CLOSE";

        VisualElement techPanel;
        ScrollView techList;

        void InitTechPanel()
        {
            techPanel = uiDocument.rootVisualElement.Q("TechPanel");
            if (techPanel == null) return;

            Label titleLabel = techPanel.Q<Label>();
            if (titleLabel != null) titleLabel.text = panelTitle;

            techList = techPanel.Q<ScrollView>("TechList");

            Button closeTechBtn = techPanel.Q<Button>("CloseTechButton");
            if (closeTechBtn != null)
            {
                closeTechBtn.text = closeButtonLabel;
                closeTechBtn.clicked += () => techPanel.style.display = DisplayStyle.None;
            }
        }

        public void ToggleTechPanel()
        {
            if (techPanel == null) return;

            if (techPanel.style.display == DisplayStyle.Flex)
            {
                techPanel.style.display = DisplayStyle.None;
            }
            else
            {
                techPanel.style.display = DisplayStyle.Flex;
                PopulateTechList();
            }
        }

        void PopulateTechList()
        {
            if (techList == null) return;

            techList.Clear();

            Technology[] allTechs = (technologies != null && technologies.Length > 0)
                ? technologies
                : Resources.LoadAll<Technology>("");

            if (sortAlphabetically)
                allTechs = allTechs.OrderBy(t => t.displayName).ToArray();

            foreach (var tech in allTechs)
            {
                bool isUnlocked = TechnologyManager.instance.isUnlocked(tech, SlotManager.instance.currentPlayer);

                if (!showUnlocked && isUnlocked) continue;

                Button btn = new Button();
                btn.text = tech.displayName + (isUnlocked ? unlockedLabel : "");
                btn.SetEnabled(!isUnlocked);
                btn.clicked += () =>
                {
                    TechnologyManager.instance.UnlockTech(tech, SlotManager.instance.currentPlayer);
                    PopulateTechList();
                };
                btn.AddToClassList("buttonColors");
                btn.style.marginTop = 5;
                btn.style.marginBottom = 5;
                techList.Add(btn);
            }
        }
    }
}
