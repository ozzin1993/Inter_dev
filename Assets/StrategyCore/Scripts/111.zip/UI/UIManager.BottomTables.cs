using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

namespace StrategyCore
{
    /// <summary>Действие ячейки нижней таблицы по клику.</summary>
    public enum BottomTableAction
    {
        None,     // только подсветка
        Attack,   // команда «Атака» группе юнитов
        Defence,  // команда «Защита» группе юнитов
    }

    /// <summary>Одна кнопка нижней таблицы: иконка + действие.</summary>
    [Serializable]
    public class BottomTableButton
    {
        [Tooltip("Иконка ячейки (как у способностей).")]
        public Texture2D icon;

        [Tooltip("Действие по клику: None — только подсветка; Attack/Defence — команда группе юнитов.")]
        public BottomTableAction action = BottomTableAction.None;

        // Произвольное действие по клику (рантайм, не из Inspector). Если задано — выполняется вместо
        // логики Attack/Defence, подсветка не ставится (моментальная кнопка). Так внешние конструкторы
        // (напр. WaveBuilderUI) кладут свои кнопки в нижнюю таблицу, не зашивая их логику в UIManager.
        [NonSerialized] public Action onClick;

        // Текст ячейки (рантайм, не из Inspector): верхняя и нижняя строки. Если заданы — ячейка рисует
        // две строки текста вместо иконки. Используется внешними конструкторами (напр. WaveBuilderUI:
        // цена сверху, текущее кол-во в волне снизу).
        [NonSerialized] public string topText;
        [NonSerialized] public string bottomText;

        // Информационная ячейка: по клику нет ни подсветки, ни действия (только показ текста).
        [NonSerialized] public bool displayOnly;
    }

    /// <summary>Содержимое одной таблицы (список кнопок слева-направо, с переносом).</summary>
    [Serializable]
    public class BottomTableContent
    {
        [Tooltip("Кнопки таблицы по порядку.")]
        public List<BottomTableButton> buttons = new List<BottomTableButton>();
    }

    /// <summary>
    /// Партиал-расширение UIManager: нижние таблицы HUD.
    /// Таблицы — контейнеры с flex-wrap (как штатный .AbilityScrollView), ячейки в стиле .AbilityButton.
    /// Содержимое настраивается в Inspector (tableContents) и/или меняется в рантайме через публичное API.
    /// Клик: подсветка штатным .activeAbility + действие ячейки (Attack/Defence — команда группе юнитов).
    /// Команды серверо-авторитетны: на сервере строй через FormationMarch, на клиенте — локальное движение.
    /// На слоте abilityTableSlot вместо общей таблицы строится отдельная ветка способностей (BottomAbilityTable):
    /// набор берётся из MatchManager.Team(commandTeamSlot).centralAbilities, иконка — из Ability.icon[0]. Сама Ability
    /// хранится в userData ячейки; клик активирует её серверо-авторитетно через фиксированного юнита-кастера
    /// команды (MatchManager.Team(slot).abilityCaster, штатный Unit.UseAbilityItem). Поддержаны Active-способности.
    /// Скрытие штатного HUD — здесь же (LateUpdate), т.к. компонент HudElementDisabler в сцене не привязан.
    /// Все размеры/количества/содержимое — в Inspector, без хардкода (правило «всё в Inspector»).
    /// </summary>
    public partial class UIManager : MonoBehaviour
    {
        [Header("Нижние таблицы")]
        [Tooltip("Сколько таблиц разместить в ряд по нижней кромке. У каждой свой источник данных.")]
        [SerializeField] int bottomTablesCount = 3;

        [Tooltip("Число столбцов в таблице. Строки добавляются автопереносом (flex-wrap). " +
                 "Отдельной таблице ширину можно переопределить в рантайме через SetBottomTableColumns.")]
        [SerializeField] int bottomTableColumns = 3;

        [Tooltip("Минимум ячеек в таблице: пустые добиваются, чтобы рамка была видна всегда. 9 = сетка 3×3.")]
        [SerializeField] int bottomTableMinCells = 9;

        [Tooltip("Ширина места под одну ячейку (кнопка + поля), px. Задаёт ширину таблицы под нужное число столбцов.")]
        [SerializeField] int bottomTableCellFootprint = 72;

        [Tooltip("Отступ таблиц от нижней кромки экрана, px.")]
        [SerializeField] int bottomTablesBottomOffset = 10;

        [Tooltip("Горизонтальный отступ контейнера таблиц от краёв экрана, px.")]
        [SerializeField] int bottomTablesSideOffset = 10;

        [Tooltip("Размер шрифта текста в ячейках цены/количества, px.")]
        [SerializeField] int bottomCellFontSize = 12;

        [Tooltip("Цвет текста в ячейках цены/количества.")]
        [SerializeField] Color bottomCellTextColor = Color.white;

        [Tooltip("Начальное содержимое таблиц. Индекс = порядок слева направо: элемент 0 — ЛЕВАЯ таблица. " +
                 "Для левой таблицы задай 2 кнопки: icon + action=Attack и icon + action=Defence. " +
                 "Слот abilityTableSlot этим массивом НЕ управляется — там отдельная ветка способностей.")]
        [SerializeField] BottomTableContent[] tableContents;

        [Tooltip("Индекс команды в MatchManager, чьими юнитами управляют кнопки Атака/Защита (0=A, 1=B). " +
                 "Этим же индексом выбирается набор способностей центральной таблицы.")]
        [SerializeField] int commandTeamSlot = 0;

        [Header("Способности (центральная таблица)")]
        [Tooltip("Позиция ветки способностей в нижнем ряду (0 = крайняя левая). При 3 таблицах 1 = центр. " +
                 "На этом слоте вместо общей таблицы строится отдельная ветка способностей. " +
                 "Вне диапазона [0..bottomTablesCount) — ветка не создаётся.")]
        [SerializeField] int abilityTableSlot = 1;

        // Набор способностей центральной таблицы больше НЕ хранится здесь — единый источник в
        // MatchManager.Team(commandTeamSlot).centralAbilities (см. CurrentTeamAbilities).

        [Header("Скрытие штатного HUD")]
        [Tooltip("Имена элементов InGame.uxml, которые скрывать каждый кадр (LateUpdate), " +
                 "чтобы внизу остались только ресурсы и нижние таблицы. Имена редактируются здесь, " +
                 "в коде не захардкожены. Ядро в рантайме само показывает часть из них (RightArea/UnitBox " +
                 "при выборе юнита), поэтому скрытие повторяется в LateUpdate после логики ядра.")]
        [SerializeField] string[] hiddenHudElements =
        {
            "RightArea",      // команды + сетка способностей (оригинальная боковая таблица)
            "MiniMap",        // миникарта
            "UnitBox",        // портрет/статы выбранного юнита
            "InventoryBox",   // инвентарь
            "TechPanel",      // панель технологий
            "TechTreeButton", // кнопка TECH
            "Status",         // иконки эффекторов
            "Descriptor",     // тултип
            "Processes",      // очередь процессов
            "Transport",      // слоты перевозимых юнитов
            "MessageBox",     // чат (вывод)
            "ChatBox",        // обёртка чата
            "Tips",           // подсказки/хоткеи
            "Debug",          // отладочная панель
        };

        VisualElement bottomTablesRoot;               // общий контейнер (всегда виден)
        VisualElement[] bottomTableContentRoots;      // контент-контейнер каждой таблицы (flex-wrap)
        List<BottomTableButton>[] bottomTableElements;// данные: текущие кнопки каждой таблицы
        VisualElement bottomAbilityTableRoot;         // отдельная ветка способностей (центральная таблица)

        readonly List<VisualElement> hiddenHudCache = new List<VisualElement>();
        bool hiddenHudResolved;

        // Текущий режим команды (Атака/Защита) для commandTeamSlot. Нужен только для подсветки UI-ячейки.
        // Переотдача команды при спавне волны и гибели башни — в MatchManager.
        BottomTableAction currentCommandMode = BottomTableAction.None;

        void InitBottomTables()
        {
            if (bottomTablesRoot != null) return;            // уже построено
            if (uiDocument == null) return;

            VisualElement root = uiDocument.rootVisualElement;
            if (root == null) return;

            if (bottomTablesCount <= 0 || bottomTableColumns <= 0) return;

            // Контейнер растянут на всю ширину по нижней кромке; таблицы распределены равномерно.
            bottomTablesRoot = new VisualElement { name = "BottomTables" };
            bottomTablesRoot.style.position = Position.Absolute;
            bottomTablesRoot.style.left = bottomTablesSideOffset;
            bottomTablesRoot.style.right = bottomTablesSideOffset;
            bottomTablesRoot.style.bottom = bottomTablesBottomOffset;
            bottomTablesRoot.style.flexDirection = FlexDirection.Row;
            bottomTablesRoot.style.justifyContent = Justify.SpaceAround;
            bottomTablesRoot.style.alignItems = Align.FlexEnd;

            bottomTableContentRoots = new VisualElement[bottomTablesCount];
            bottomTableElements = new List<BottomTableButton>[bottomTablesCount];

            float tableWidth = bottomTableColumns * bottomTableCellFootprint;

            for (int i = 0; i < bottomTablesCount; i++)
            {
                // Слот способностей — отдельная ветка (свои данные/рендер), а не общая таблица.
                // generic-массивы на этом индексе остаются null: общий API его не трогает (IsValidBottomTable).
                if (i == abilityTableSlot)
                {
                    BuildAbilityTableBranch(tableWidth);
                    continue;
                }

                // Стартовое содержимое из Inspector (если задано для этого индекса).
                bottomTableElements[i] = new List<BottomTableButton>();
                if (tableContents != null && i < tableContents.Length
                    && tableContents[i] != null && tableContents[i].buttons != null)
                    bottomTableElements[i].AddRange(tableContents[i].buttons);

                // Таблица: ряд с переносом — ширина фиксирует число столбцов, строки растут вниз.
                VisualElement table = new VisualElement { name = "BottomTable" };
                table.style.flexDirection = FlexDirection.Row;
                table.style.flexWrap = Wrap.Wrap;
                table.style.width = tableWidth;
                // Подсветка/команда по клику — делегирование с контейнера (как штатный AbilityHandler).
                table.RegisterCallback<ClickEvent>(OnBottomTableClick);
                bottomTablesRoot.Add(table);
                bottomTableContentRoots[i] = table;

                RenderBottomTable(i);
            }

            root.Add(bottomTablesRoot);
        }

        // --- Публичное API управления содержимым (вызывать по мере изменений в матче) ---

        /// <summary>Полностью задать содержимое таблицы.</summary>
        public void SetBottomTableElements(int tableIndex, IEnumerable<BottomTableButton> buttons)
        {
            if (!IsValidBottomTable(tableIndex)) return;
            bottomTableElements[tableIndex].Clear();
            if (buttons != null) bottomTableElements[tableIndex].AddRange(buttons);
            RenderBottomTable(tableIndex);
        }

        /// <summary>Добавить кнопку в таблицу.</summary>
        public void AddBottomTableElement(int tableIndex, BottomTableButton button)
        {
            if (!IsValidBottomTable(tableIndex) || button == null) return;
            bottomTableElements[tableIndex].Add(button);
            RenderBottomTable(tableIndex);
        }

        /// <summary>Убрать кнопку из таблицы. Возвращает true, если кнопка была найдена.</summary>
        public bool RemoveBottomTableElement(int tableIndex, BottomTableButton button)
        {
            if (!IsValidBottomTable(tableIndex)) return false;
            bool removed = bottomTableElements[tableIndex].Remove(button);
            if (removed) RenderBottomTable(tableIndex);
            return removed;
        }

        /// <summary>Очистить таблицу (останутся только пустые ячейки до минимума).</summary>
        public void ClearBottomTable(int tableIndex)
        {
            if (!IsValidBottomTable(tableIndex)) return;
            bottomTableElements[tableIndex].Clear();
            RenderBottomTable(tableIndex);
        }

        bool IsValidBottomTable(int tableIndex)
        {
            // Слот способностей хранит null в generic-массиве — общий API его не обслуживает.
            return bottomTableElements != null
                && tableIndex >= 0 && tableIndex < bottomTableElements.Length
                && bottomTableElements[tableIndex] != null;
        }

        /// <summary>
        /// Задать число столбцов конкретной таблицы в рантайме (ширина = columns × footprint).
        /// Нужно внешним конструкторам, кладущим в ряд больше ячеек, чем общее число столбцов
        /// (напр. WaveBuilderUI: иконка/+/−/цена). Другие таблицы не затрагиваются.
        /// </summary>
        public void SetBottomTableColumns(int tableIndex, int columns)
        {
            if (bottomTableContentRoots == null) return;
            if (tableIndex < 0 || tableIndex >= bottomTableContentRoots.Length) return;
            if (columns <= 0) return;
            VisualElement table = bottomTableContentRoots[tableIndex];
            if (table == null) return;     // напр. слот способностей (своя ветка)
            table.style.width = columns * bottomTableCellFootprint;
        }

        /// <summary>Команда локального игрока (0=A, 1=B) — единый источник для внешних конструкторов кнопок.</summary>
        public int CommandTeamSlot => commandTeamSlot;

        /// <summary>Готовы ли нижние таблицы (InitBottomTables отработал) — для отложенного наполнения извне.</summary>
        public bool BottomTablesReady => bottomTableElements != null;

        // Перестраивает ячейки таблицы из её текущего списка (как штатный RebuildAbilityView).
        void RenderBottomTable(int tableIndex)
        {
            if (bottomTableContentRoots == null) return;
            if (tableIndex < 0 || tableIndex >= bottomTableContentRoots.Length) return;

            VisualElement table = bottomTableContentRoots[tableIndex];
            if (table == null) return;

            table.Clear();

            List<BottomTableButton> elements = bottomTableElements[tableIndex];

            // Занятые ячейки (с иконками и действием).
            for (int i = 0; i < elements.Count; i++)
                table.Add(BuildBottomCell(elements[i]));

            // Пустые ячейки до минимума — штатным методом ассета (рамка видна всегда).
            for (int i = elements.Count; i < bottomTableMinCells; i++)
                EmptyElementCreate(table, i);
        }

        // Ячейка в стиле кнопки способности. Действие/данные хранятся в userData для обработки клика.
        // Если у кнопки задан текст (topText/bottomText) — рисуем две строки вместо иконки.
        GroupBox BuildBottomCell(BottomTableButton button)
        {
            GroupBox cell = new GroupBox();
            cell.AddToClassList("AbilityButton");
            cell.userData = button;   // вся кнопка: действие Attack/Defence, произвольный onClick или текст

            bool hasText = button != null
                && (!string.IsNullOrEmpty(button.topText) || !string.IsNullOrEmpty(button.bottomText));

            if (hasText)
            {
                // Текстовая ячейка: верхняя строка (цена) над нижней (кол-во). По центру.
                cell.style.justifyContent = Justify.Center;
                cell.style.alignItems = Align.Center;

                Label topLabel = new Label(button.topText ?? string.Empty);
                Label bottomLabel = new Label(button.bottomText ?? string.Empty);
                StyleBottomCellLabel(topLabel);
                StyleBottomCellLabel(bottomLabel);
                cell.Add(topLabel);
                cell.Add(bottomLabel);
            }
            else
            {
                GroupBox iconElement = new GroupBox();
                iconElement.AddToClassList("AbilityButtonIcon");
                if (button != null && button.icon != null)
                    iconElement.style.backgroundImage = button.icon;   // Texture2D → StyleBackground
                cell.Add(iconElement);
            }

            return cell;
        }

        // Единый стиль строк текстовой ячейки (размер/цвет — из Inspector, без хардкода).
        void StyleBottomCellLabel(Label label)
        {
            label.style.fontSize = bottomCellFontSize;
            label.style.color = bottomCellTextColor;
            label.style.unityTextAlign = TextAnchor.MiddleCenter;
        }

        // --- Ветка способностей (центральная таблица) ---

        // Строит отдельный контейнер способностей и ставит его в нужную позицию нижнего ряда.
        // Тот же стиль/механика, что у общих таблиц (flex-wrap, .AbilityButton), но свои данные/рендер.
        void BuildAbilityTableBranch(float tableWidth)
        {
            VisualElement table = new VisualElement { name = "BottomAbilityTable" };
            table.style.flexDirection = FlexDirection.Row;
            table.style.flexWrap = Wrap.Wrap;
            table.style.width = tableWidth;
            // Клик — тот же обработчик: у Ability-ячеек userData не BottomTableButton, поэтому только подсветка.
            table.RegisterCallback<ClickEvent>(OnBottomTableClick);
            bottomTablesRoot.Add(table);
            bottomAbilityTableRoot = table;

            RenderAbilityTable();
        }

        // Перестраивает ячейки центральной таблицы из набора способностей текущей команды (commandTeamSlot).
        void RenderAbilityTable()
        {
            if (bottomAbilityTableRoot == null) return;

            bottomAbilityTableRoot.Clear();

            List<Ability> abilities = CurrentTeamAbilities();
            int count = abilities != null ? abilities.Count : 0;

            // Занятые ячейки — иконки способностей.
            for (int i = 0; i < count; i++)
                bottomAbilityTableRoot.Add(BuildAbilityCell(abilities[i]));

            // Пустые ячейки до минимума — штатным методом ассета (рамка видна всегда).
            for (int i = count; i < bottomTableMinCells; i++)
                EmptyElementCreate(bottomAbilityTableRoot, i);
        }

        // Набор способностей команды локального игрока. Единый источник — MatchManager.Team(slot).centralAbilities
        // (тот же список, что прописывается в abilities[] кастера для каста). Отдельного UI-поля больше нет.
        List<Ability> CurrentTeamAbilities()
        {
            MatchManager mm = MatchManager.instance;
            if (mm == null) return null;
            TeamWaveConfig team = mm.Team(commandTeamSlot);
            return team != null ? team.centralAbilities : null;
        }

        // Ячейка способности в стиле кнопки. Сама Ability хранится в userData (для будущей активации);
        // сейчас клик по ней даёт только подсветку (см. OnBottomTableClick).
        GroupBox BuildAbilityCell(Ability ability)
        {
            GroupBox cell = new GroupBox();
            cell.AddToClassList("AbilityButton");
            cell.userData = ability;

            GroupBox iconElement = new GroupBox();
            iconElement.AddToClassList("AbilityButtonIcon");
            if (ability != null && ability.icon != null && ability.icon.Length > 0 && ability.icon[0] != null)
                iconElement.style.backgroundImage = ability.icon[0];   // Texture2D → StyleBackground
            cell.Add(iconElement);

            return cell;
        }

        /// <summary>Перерисовать центральную таблицу способностей (напр. после смены команды игрока).</summary>
        public void RefreshAbilityTable()
        {
            RenderAbilityTable();
        }

        // Активация способности из центральной таблицы фиксированным юнитом-кастером команды.
        // Серверо-авторитетно: штатный Unit.UseAbilityItem сам отправит команду серверу на клиенте
        // (NetworkConnectionHandler.isClient → NetworkCommandSync), на сервере исполнит (правило 6).
        // Поддержаны только Active-способности (без выбора цели на карте).
        void ActivateAbilityCell(Ability ability)
        {
            if (ability == null) return;
            Debug.Log($"[UIManager] Клик по способности: '{ability.name}', тип={ability.type}, команда={commandTeamSlot}.");

            if (ability.type != AbilityType.Active)            // таргетные/прочие — вне текущего объёма
            {
                Debug.LogWarning($"[UIManager] '{ability.name}': тип {ability.type} ≠ Active — каст из таблицы не поддержан.");
                return;
            }

            MatchManager mm = MatchManager.instance;
            if (mm == null) { Debug.LogWarning("[UIManager] MatchManager.instance == null — каст невозможен."); return; }

            TeamWaveConfig team = mm.Team(commandTeamSlot);
            Unit caster = team != null ? team.abilityCaster : null;
            if (caster == null || caster.dead)                 // нет персистентного кастера — каст невозможен
            {
                Debug.LogWarning($"[UIManager] Нет живого кастера (abilityCaster) команды {commandTeamSlot} — каст невозможен.");
                return;
            }
            if (caster.abilities == null || caster.abilities.Length == 0) // у кастера нет способностей
            {
                Debug.LogWarning($"[UIManager] У кастера {caster.name} пустой список abilities — каст невозможен.");
                return;
            }

            // Каст идёт по индексу в abilities[] кастера (штатный контракт). Способность должна быть у кастера.
            // Utils.GetAbilityIndex при «не найдено» возвращает не -1 (баг ассета: результат поиска игнорируется),
            // поэтому подтверждаем индекс обратной выборкой GetAbilityByIndex.
            int abilityIndex = Utils.GetAbilityIndex(caster.abilities, ability);
            if (abilityIndex < 0 || Utils.GetAbilityByIndex(caster, abilityIndex) != ability)
            {
                Debug.LogWarning($"[UIManager] Способность {ability.name} не найдена в abilities кастера " +
                                 $"{caster.name} (команда {commandTeamSlot}) — каст пропущен.");
                return;
            }

            bool ok = caster.UseAbilityItem(abilityIndex, false, null, Vector3.zero, true);
            Debug.Log($"[UIManager] UseAbilityItem('{ability.name}', index={abilityIndex}, кастер={caster.name}) → {ok}.");
        }

        // Клик по таблице: подсветка штатным .activeAbility + действие ячейки (если задано).
        // Делегирование с контейнера. Повторный клик снимает выделение. Выбор — по одной на таблицу.
        void OnBottomTableClick(ClickEvent evt)
        {
            VisualElement target = evt.target as VisualElement;
            if (target == null) return;

            // Поднимаемся до самой ячейки (.AbilityButton).
            VisualElement cell = target;
            while (cell != null && !cell.ClassListContains("AbilityButton"))
                cell = cell.parent;
            if (cell == null) return;
            Debug.Log($"[UIManager] Клик по ячейке нижней таблицы зафиксирован (userData={(cell.userData != null ? cell.userData.GetType().Name : "null")}).");

            BottomTableButton button = cell.userData as BottomTableButton;

            // Информационная ячейка (цена/кол-во) — ни подсветки, ни действия.
            if (button != null && button.displayOnly) return;

            // Произвольное действие (моментальная кнопка, напр. конструктор волны) — выполнить и выйти,
            // подсветку не трогаем.
            if (button != null && button.onClick != null) { button.onClick(); return; }

            // Ячейка способности (userData = Ability): серверо-авторитетный каст по клику.
            // Моментальная кнопка — без залипающей подсветки (как onClick выше).
            Ability clickedAbility = cell.userData as Ability;
            if (clickedAbility != null) { ActivateAbilityCell(clickedAbility); return; }

            VisualElement table = cell.parent;
            if (table == null) return;

            bool wasActive = cell.ClassListContains("activeAbility");

            // Снять подсветку со всех ячеек этой таблицы.
            for (int i = 0; i < table.childCount; i++)
                table.ElementAt(i).RemoveFromClassList("activeAbility");

            // Переключить выделение кликнутой ячейки.
            if (!wasActive) cell.AddToClassList("activeAbility");

            BottomTableAction action = button != null ? button.action : BottomTableAction.None;
            if (action != BottomTableAction.None)
            {
                if (!wasActive)
                {
                    // Выбор командной ячейки: запоминаем для подсветки, делегируем в MatchManager.
                    currentCommandMode = action;
                    ExecuteBottomTableCommand(action);
                }
                else
                {
                    // Снятие выбора: прекращаем наследование режима новыми юнитами.
                    currentCommandMode = BottomTableAction.None;
                }
            }
        }

        // --- Команды Атака/Защита ---

        // Делегирует выполнение команды в MatchManager. Вся логика формаций и юнитов — там.
        void ExecuteBottomTableCommand(BottomTableAction action)
        {
            if (action == BottomTableAction.None) return;
            MatchManager mm = MatchManager.instance;
            if (mm == null) return;
            if (action == BottomTableAction.Attack)        mm.SendAttackCommand(commandTeamSlot);
            else if (action == BottomTableAction.Defence)  mm.SendDefenceCommand(commandTeamSlot);
        }

        // --- Скрытие штатного HUD ---

        // UIManager сам показывает часть элементов в рантайме, поэтому скрываем в LateUpdate
        // (после Update ядра) — элемент не успевает отрисоваться.
        void LateUpdate()
        {
            if (!hiddenHudResolved && !ResolveHiddenHud()) return;

            for (int i = 0; i < hiddenHudCache.Count; i++)
            {
                VisualElement ve = hiddenHudCache[i];
                if (ve != null && ve.style.display != DisplayStyle.None)
                    ve.style.display = DisplayStyle.None;
            }
        }

        bool ResolveHiddenHud()
        {
            if (uiDocument == null) return false;

            VisualElement root = uiDocument.rootVisualElement;
            if (root == null) return false;

            hiddenHudCache.Clear();
            for (int i = 0; i < hiddenHudElements.Length; i++)
            {
                string elementName = hiddenHudElements[i];
                if (string.IsNullOrEmpty(elementName)) continue;

                VisualElement ve = root.Q(elementName);
                if (ve != null) hiddenHudCache.Add(ve);
            }

            hiddenHudResolved = true;
            return true;
        }
    }
}
