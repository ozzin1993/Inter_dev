using System.Collections.Generic;
using UnityEngine;

namespace StrategyCore
{
    /// <summary>
    /// Авто-применение способности юнитом: поиск цели по выбранной стратегии и каст
    /// штатным Unit.UseAbilityItem. Серверо-авторитетно — на клиенте бездействует (правило 6).
    /// Тик — на штатном GameManager.Tick (0.1 с); КД, ману, muted и требования проверяет
    /// сам UseAbilityItem, своих проверок не дублируем (правило 2).
    /// «Категория» юнита (для приоритета цели) хранится здесь — Unit.cs не трогаем (правило 1).
    /// После каста с прерыванием юнит возвращается к команде через MatchManager.ReissueCurrentCommand.
    /// </summary>
    // Без [RequireComponent(typeof(Unit))]: ассет снимает Unit через Utils.UnitRemoveComponents
    // (апгрейд/трансформация/статик-копия), а зависимость блокировала бы удаление Unit.
    // Unit берём через GetComponent в Awake; если его нет — компонент бездействует (гарды).
    public class AutoAbilityUser : MonoBehaviour
    {
        // Стратегия выбора цели. Один тип на юнит, задаётся в инспекторе.
        public enum TargetingStrategy
        {
            [InspectorName("Самый раненый союзник в радиусе")]
            MostWoundedAlly,
            [InspectorName("Случайный враг в радиусе (с приоритетом по категории)")]
            RandomEnemyWithTypePriority,
            [InspectorName("Ближайший враг в радиусе")]
            NearestEnemy
        }

        // Категория юнита. Хранится на этом компоненте, не на Unit.
        public enum UnitCategory
        {
            [InspectorName("Боец")] Fighter,
            [InspectorName("Танк")] Tank,
            [InspectorName("Стрелок")] Shooter,
            [InspectorName("Маг")] Mage
        }

        [Header("Категория")]
        [Tooltip("Категория этого юнита. Другие юниты используют её для приоритета цели.")]
        [SerializeField] private UnitCategory selfCategory = UnitCategory.Fighter;

        [Header("Целеискание")]
        [Tooltip("Стратегия выбора цели для авто-каста.")]
        [SerializeField] private TargetingStrategy targetingStrategy = TargetingStrategy.RandomEnemyWithTypePriority;

        [Tooltip("Радиус поиска цели, мировые единицы.")]
        [SerializeField] private float searchRadius = 8f;

        [Tooltip("Кого считать кандидатами на цель (свой/союзник/враг + тип передвижения). " +
                 "Стратегия выбирает уже среди них. Для 'раненый союзник' — поставьте союзник+свой; для врага — враг.")]
        [SerializeField] private UnitSelector candidateSelector =
            new UnitSelector(false, false, true, true, false, false, false, true, true, true, false, false);

        [Tooltip("Только для стратегии 'Случайный враг': какую категорию врага предпочитать. " +
                 "Приоритет учитывается только у кандидатов, у которых тоже есть AutoAbilityUser.")]
        [SerializeField] private UnitCategory priorityCategory = UnitCategory.Mage;

        [Header("Способность")]
        [Tooltip("Способность для авто-каста. Должна также присутствовать в списке Abilities этого юнита " +
                 "(каст идёт по индексу в пуле). Тип (Active/Unit/Area/Location) определяется автоматически.")]
        [SerializeField] private Ability autoAbility;

        // --- внутреннее состояние ---
        private Unit unit;
        private bool subscribed;
        private bool abilityResolved;
        private int cachedAbilityIndex = -1;
        private UnitStates prevState = UnitStates.Idle;

        /// <summary>Категория этого юнита (для чтения другими AutoAbilityUser).</summary>
        public UnitCategory Category => selfCategory;

        private void Awake()
        {
            unit = GetComponent<Unit>();
        }

        private void OnEnable() => TrySubscribe();
        private void Start() => TrySubscribe();
        private void OnDisable() => Unsubscribe();
        private void OnDestroy() => Unsubscribe();

        private void TrySubscribe()
        {
            if (subscribed) return;
            if (GameManager.instance == null) return;
            GameManager.instance.Tick += OnTick;
            prevState = unit != null ? unit.unitState : UnitStates.Idle;
            subscribed = true;
        }

        private void Unsubscribe()
        {
            if (!subscribed) return;
            if (GameManager.instance != null) GameManager.instance.Tick -= OnTick;
            subscribed = false;
        }

        // Штатный тик ассета (0.1 с). Решение о цели — только на сервере (правило 6).
        private void OnTick()
        {
            if (NetworkConnectionHandler.isClient) return;
            if (unit == null || unit.dead) return;

            // 1) Возврат к команде после завершения каста (переход AbilityCasting → не-каст).
            //    Мгновенные способности (без castRange/castTime) в AbilityCasting не входят,
            //    движение не прерывают — для них этот блок не срабатывает, что и нужно.
            if (prevState == UnitStates.AbilityCasting && unit.unitState != UnitStates.AbilityCasting)
            {
                if (MatchManager.instance != null)
                    MatchManager.instance.ReissueCurrentCommand(unit);
            }

            // 2) Попытка авто-каста. Если КД не готов / нет маны / muted — UseAbilityItem вернёт false.
            TryAutoCast();

            prevState = unit.unitState;
        }

        private void TryAutoCast()
        {
            if (autoAbility == null) return;
            if (unit.unitState == UnitStates.AbilityCasting) return; // уже кастует

            int idx = ResolveAbilityIndex();
            if (idx < 0) return;

            Vector2 pos = new Vector2(transform.position.x, transform.position.z);
            Unit[] candidates = Utils.GetUnitsInRadius(pos, searchRadius, unit.owner, candidateSelector, -1, unit);
            Unit target = PickTarget(candidates);

            switch (autoAbility.type)
            {
                case AbilityType.Unit:
                    if (target == null) return;
                    unit.UseAbilityItem(idx, false, target, Vector3.zero);
                    break;
                case AbilityType.Area:
                case AbilityType.Location:
                    if (target == null) return;
                    unit.UseAbilityItem(idx, false, null, target.transform.position);
                    break;
                case AbilityType.Active:
                    // Active не имеет цели — кастуем при наличии подходящего кандидата в радиусе.
                    if (target == null) return;
                    unit.UseAbilityItem(idx, false, null, Vector3.zero);
                    break;
                // Прочие типы (Toggle/Aura/Passive/Process/...) — вне объёма авто-каста.
            }
        }

        // Выбор цели среди кандидатов по стратегии. null — если подходящих нет.
        private Unit PickTarget(Unit[] candidates)
        {
            if (candidates == null || candidates.Length == 0) return null;

            switch (targetingStrategy)
            {
                case TargetingStrategy.MostWoundedAlly:
                {
                    Unit best = null;
                    float bestRatio = float.MaxValue;
                    for (int i = 0; i < candidates.Length; i++)
                    {
                        Unit c = candidates[i];
                        if (c == null || c.dead || c == unit) continue;
                        if (c.maxHealth <= 0f) continue;
                        float ratio = c.health / c.maxHealth;
                        if (ratio < bestRatio)
                        {
                            bestRatio = ratio;
                            best = c;
                        }
                    }
                    return best;
                }
                case TargetingStrategy.RandomEnemyWithTypePriority:
                {
                    // Приоритетная подгруппа — кандидаты нужной категории (если у них есть AutoAbilityUser).
                    // Пусто — берём всех валидных.
                    List<Unit> all = new List<Unit>();
                    List<Unit> priority = new List<Unit>();
                    for (int i = 0; i < candidates.Length; i++)
                    {
                        Unit c = candidates[i];
                        if (c == null || c.dead || c == unit) continue;
                        all.Add(c);
                        AutoAbilityUser other = c.GetComponent<AutoAbilityUser>();
                        if (other != null && other.selfCategory == priorityCategory)
                            priority.Add(c);
                    }
                    List<Unit> pool = priority.Count > 0 ? priority : all;
                    if (pool.Count == 0) return null;
                    return pool[Random.Range(0, pool.Count)];
                }
                case TargetingStrategy.NearestEnemy:
                {
                    // Ближайший к нам кандидат. «Первого зашедшего в радиус» обеспечивает тик:
                    // как только враг входит в радиус, он становится ближайшим и кастуется.
                    Unit best = null;
                    float bestSqr = float.MaxValue;
                    Vector3 self = transform.position;
                    for (int i = 0; i < candidates.Length; i++)
                    {
                        Unit c = candidates[i];
                        if (c == null || c.dead || c == unit) continue;
                        float sqr = (c.transform.position - self).sqrMagnitude;
                        if (sqr < bestSqr)
                        {
                            bestSqr = sqr;
                            best = c;
                        }
                    }
                    return best;
                }
            }
            return null;
        }

        // Индекс способности в пуле юнита (кэш). Обход бага Utils.GetAbilityIndex
        // (при «не найдено» возвращает не -1) кросс-проверкой GetAbilityByIndex — как в UIManager.BottomTables.
        private int ResolveAbilityIndex()
        {
            if (abilityResolved) return cachedAbilityIndex;
            abilityResolved = true;
            cachedAbilityIndex = -1;
            if (autoAbility == null || unit.abilities == null) return -1;

            int idx = Utils.GetAbilityIndex(unit.abilities, autoAbility);
            if (idx >= 0 && Utils.GetAbilityByIndex(unit, idx) == autoAbility)
                cachedAbilityIndex = idx;
            else
                Debug.LogWarning($"[AutoAbilityUser] У '{unit.unitName}' способность '{autoAbility.name}' " +
                                 "не найдена в списке Abilities — авто-каст отключён.");
            return cachedAbilityIndex;
        }
    }
}
