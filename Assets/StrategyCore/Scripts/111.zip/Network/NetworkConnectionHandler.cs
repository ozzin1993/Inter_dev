using System;
using System.Collections;
using System.Collections.Generic;
using Unity.Netcode;
using Unity.Netcode.Transports.UTP;
using UnityEngine;
using UnityEngine.SceneManagement;
#if UNITY_EDITOR
using UnityEditor;
#endif

namespace StrategyCore
{
    public class NetworkConnectionHandler : MonoBehaviour
    {
        public static NetworkConnectionHandler instance;
        [HideInInspector] public static bool isClient = false; // Defines if the current machine is client

        [Tooltip("Reference to prefab of network handler")]
        public GameObject networkHandler;
        private GameObject m_networkHandler;

        // List of clients still loading the game. Used to track if all players loaded the game.
        public List<ulong> clientsLoading = new List<ulong>();
        public Action clientsListUpdated; // Called when clients list is updated
        public int connectionStage; // Which connection sync stage are we on; 0 - standard, 1 - sending the save data, 2 - joining midgame

        [HideInInspector] public bool exitingPlayerMode;

        void Awake()
        {
            if (instance == null)
            {
                instance = this;
#if UNITY_EDITOR
                EditorApplication.playModeStateChanged += OnPlayModeStateChanged;
#endif
            }
            else
            {
                // Remove the duplicate project manager
                Destroy(this.gameObject);
            }
        }

        void OnDestroy()
        {
#if UNITY_EDITOR
            EditorApplication.playModeStateChanged -= OnPlayModeStateChanged;
#endif
        }

        void Start()
        {
            NetworkManager.Singleton.ConnectionApprovalCallback = ConnectionApproval;
            NetworkManager.Singleton.OnClientConnectedCallback += ClientConnected;
            NetworkManager.Singleton.OnClientDisconnectCallback += ClientDisconnected;
        }

        // ============================= CLIENT WAITING LIST ==============================================================================

        /// <summary>
        /// Adds all connected players to the waiting list.
        /// </summary>
        /// <param name="noServer">Should server also be added.</param>
        public void AddClientsToWaitingList(bool noServer = false)
        {
            for (int i = 0; i < SlotManager.instance.playerID.Length; i++)
            {
                if (SlotManager.instance.playerID[i] != -1)
                {
                    if (noServer && SlotManager.instance.playerID[i] == 0) continue;
                    NetworkConnectionHandler.instance.clientsLoading.Add((ulong)SlotManager.instance.playerID[i]);
                }
            }
        }

        /// <summary>
        /// Removes the client from the waiting list.
        /// </summary>
        /// <param name="ClientID">Client`s network ID.</param>
        public void ClientsWaitingListRemove(ulong ClientID)
        {
            NetworkConnectionHandler.instance.clientsLoading.Remove(ClientID);
            clientsListUpdated?.Invoke();
        }

        // ============================= PAUSE / RESUME ==============================================================================

        /// <summary>
        /// Pauses the game for everyone.
        /// </summary>
        public void PauseTheGame()
        {
            // Pause the game
            Time.timeScale = 0;
            SlotManager.instance.gameOn = false;
            UIManagerMenu.instance.ShowUIDocument();
            UIManagerMenu.instance.ShowMenuLobby(2);

            // Pause the game for clients
            if (NetworkManager.Singleton.IsServer)
            {
                NetworkDataSync.instance.ForceSend();
                NetworkDataSync.instance.PauseTheGameClientRpc();
            }
        }

        /// <summary>
        /// Resumes the game for everyone.
        /// </summary>
        /// <param name="clearSaves">Should remove temporary save data on the clients.</param>
        public void ResumeTheGame(bool clearSaves = false)
        {
            // Resume the game for clients
            if (NetworkManager.Singleton.IsServer)
            {
                NetworkDataSync.instance.ResumeTheGameSend(clearSaves);
            }

            Time.timeScale = 1;
            NetworkConnectionHandler.instance.connectionStage = 0;
            UIManagerMenu.instance.HideUIDocument();
            SlotManager.instance.SetGameState(GameState.Started);
        }

        // ============================= CONNECT / DISCONNECT CALLBACKS ==============================================================================

        /// <summary>
        /// Callback when client connects. Called both on the server when any client, including self, connects and on clients when they themselves connect.
        /// </summary>
        private void ClientConnected(ulong clientId)
        {
            // Everyone: define if client
            if (!NetworkManager.Singleton.IsHost && NetworkManager.Singleton.IsClient) isClient = true;

            // Show lobby
            if (SlotManager.instance.gameStarted == GameState.Menu)
            {
                if (clientId == NetworkManager.Singleton.LocalClientId) UIManagerMenu.instance.ShowMenuLobby(1);
                UIManagerMenu.instance.FillPlayerList();
                NetworkConnectionHandler.instance.connectionStage = 0; // We are not joining mid-game
            }

            // Server: 
            if (NetworkManager.Singleton.IsServer)
            {
                // Send player information
                if (clientId != NetworkManager.Singleton.LocalClientId)
                {
                    NetworkDataSync.instance.PlayerListSend(clientId);

                    // Joining midgame, send scene information
                    if (SlotManager.instance.gameStarted == GameState.Started)
                    {
                        NetworkDataSync.instance.SendSceneData(clientId, true);
                    }
                }
                // Else: set current player
                else
                {
                    SlotManager.instance.SetCurrentPlayer(SlotManager.instance.GetClientSlot(clientId));
                }

                // Chat msg send
                string msg = SlotManager.instance.playerName[SlotManager.instance.GetClientSlot(clientId)] + " connected to the game.";
                if (SlotManager.instance.gameStarted == GameState.Menu) UIManagerMenu.instance.AddChatServerMsg(msg);
                else UIManager.instance.AddChatServerMsg(msg);
            }
        }

        /// <summary>
        /// Callback when client disconnects. Called both on the server when any client, including self, disconnects and on clients when they themselves connect.
        /// </summary>
        private void ClientDisconnected(ulong clientId)
        {
            if (clientId == NetworkManager.Singleton.LocalClientId)
            {
                // Local client disconnected

                // CleanUp
                NetworkConnectionHandler.instance.clientsListUpdated -= NetworkDataSync.instance.ServerStartLoading;
                NetworkConnectionHandler.instance.clientsListUpdated -= NetworkDataSync.instance.ServerPlayersFinishedLoading;
                SceneHandler.instance.UnloadScene();
                isClient = false;
                SlotManager.instance.SetGameState(GameState.Menu);
                SlotManager.instance.unitNetID = new Dictionary<UInt16, Unit>();
                // Menu
                UIManagerMenu.instance.ShowUIDocument();
                UIManagerMenu.instance.ShowMenuLobby(0);
                // NetworkManager.Singleton.SceneManager.OnSceneEvent -= SceneHandler.instance.SceneManager_OnSceneEvent;
            }
            else
            {
                // To prevent a bug that makes server trigger as client? when exiting the player mode
                if (exitingPlayerMode) return;

                // Chat msg send
                string msg = SlotManager.instance.playerName[SlotManager.instance.GetClientSlot(clientId)] + " disconnected from the game.";
                if (SlotManager.instance.gameStarted == GameState.Menu) UIManagerMenu.instance.AddChatServerMsg(msg);
                else UIManager.instance.AddChatServerMsg(msg);

                // Server: Someone disconnected
                SlotManager.instance.RemoveClientID(clientId);
                if (SlotManager.instance.gameStarted == GameState.Menu)
                {
                    // Refresh lobby
                    UIManagerMenu.instance.FillPlayerList();
                }
                else if (SlotManager.instance.gameStarted == GameState.Started)
                {
                    // Remove from the list
                    NetworkConnectionHandler.instance.ClientsWaitingListRemove(clientId);
                }
                // Send player information to clients
                NetworkDataSync.instance.PlayerListSend(clientId, true);
            }
        }

        /// <summary>
        /// Connection approval on the server when client tries to connect.
        /// </summary>
        private void ConnectionApproval(NetworkManager.ConnectionApprovalRequest request, NetworkManager.ConnectionApprovalResponse response)
        {
            // When loading, do not approve connections
            if (SlotManager.instance.gameStarted == GameState.Loading)
            {
                response.Approved = false;
                response.Pending = false;
                return;
            }

            var clientName = System.Text.Encoding.UTF8.GetString(request.Payload);
            int slot = SlotManager.instance.AddClientID(request.ClientNetworkId, clientName);
            if (slot == -1)
            {
                // Not approved
                response.Approved = false;
                response.Reason = "No available slots";
                Debug.Log("Not approved: No available slots. Tried to join " + clientName + ", " + request.ClientNetworkId);
            }
            else
            {
                // Approved
                response.Approved = true;
                Debug.Log("Approved: joined " + clientName + ", " + request.ClientNetworkId + " at slot " + slot);

                // If game has started, client is joining midgame. Pause the game. In Connection callback we will send the scene information
                if (SlotManager.instance.gameStarted == GameState.Started)
                {
                    clientsLoading.Add(request.ClientNetworkId);
                    PauseTheGame();
                    NetworkConnectionHandler.instance.clientsListUpdated += NetworkDataSync.instance.ServerPlayersFinishedLoading;
                }
            }
            response.Pending = false;
        }

        // ============================= HOST / CLIENT ==============================================================================

        /// <summary>
        /// Start the game as a host.
        /// </summary>
        /// <param name="name">Host name.</param>
        public void StartHost(string name)
        {
            // Game already started, most likely hosting without a lobby.
            if (SlotManager.instance.gameStarted == GameState.Started)
            {
                SlotManager.instance.InitializeSlotData();
                NetworkManager.Singleton.StartHost();
                m_networkHandler = Instantiate(networkHandler);
                m_networkHandler.GetComponent<NetworkObject>().Spawn();
                NetworkManager.Singleton.SceneManager.OnSceneEvent += SceneHandler.instance.SceneManager_OnSceneEvent;
                return;
            }

            // We are hosting from a lobby

            if (NetworkManager.Singleton.ShutdownInProgress || NetworkManager.Singleton.IsListening) return;
            if (!IsPortAvailable(NetworkManager.Singleton.GetComponent<UnityTransport>().ConnectionData.Port)) return; // Check port not implemented

            // UI connection menu
            UIManagerMenu.instance.ShowMenuLobby(2);
            // Preparation
            if (m_networkHandler) Destroy(m_networkHandler);
            SlotManager.instance.InitializeSlotData();
            // Settings for host
            NetworkManager.Singleton.NetworkConfig.ConnectionData = System.Text.Encoding.ASCII.GetBytes(name); // Send host`s name
            NetworkManager.Singleton.StartHost();
            // Data
            m_networkHandler = Instantiate(networkHandler);
            m_networkHandler.GetComponent<NetworkObject>().Spawn();
            NetworkManager.Singleton.SceneManager.SetClientSynchronizationMode(LoadSceneMode.Additive);
            NetworkManager.Singleton.SceneManager.ActiveSceneSynchronizationEnabled = true;
            NetworkManager.Singleton.SceneManager.OnSceneEvent += SceneHandler.instance.SceneManager_OnSceneEvent;
        }

        /// <summary>
        /// Start the game as a client.
        /// </summary>
        /// <param name="name">Client name.</param>
        /// <param name="address">Connectiona address.</param>
        /// <param name="port">Connection port.</param>
        public void StartClient(string name, string address = null, string port = null)
        {
            // Game already started, most likely connecting without a lobby.
            if (SlotManager.instance.gameStarted == GameState.Started)
            {
                NetworkManager.Singleton.StartClient();
                NetworkManager.Singleton.SceneManager.OnSceneEvent += SceneHandler.instance.SceneManager_OnSceneEvent;
                return;
            }

            // We are connecting from a lobby

            if (NetworkManager.Singleton.ShutdownInProgress || NetworkManager.Singleton.IsListening) return;

            // Set address and port
            if (address != null)
            {
                var unityTransport = NetworkManager.Singleton.GetComponent<UnityTransport>();

                if (unityTransport != null)
                {
                    unityTransport.SetConnectionData(
                        address,  // The IP address is a string
                        ushort.Parse(port) // The port number is an unsigned short
                    );
                }
                else
                {
                    Debug.LogError("Unity Transport is not attached to the NetworkManager.");
                }
            }

            // UI connection menu
            UIManagerMenu.instance.ShowMenuLobby(2);
            // Set name and start client
            NetworkManager.Singleton.NetworkConfig.ConnectionData = System.Text.Encoding.ASCII.GetBytes(name); // Send client`s name
            NetworkManager.Singleton.StartClient();
            NetworkManager.Singleton.SceneManager.OnSceneEvent += SceneHandler.instance.SceneManager_OnSceneEvent;
            NetworkConnectionHandler.instance.connectionStage = 2; // Assume we are joining midgame. Set to false in connected calback if we are in the lobby.
        }

        /// <summary>
        /// Shut down the connection on a local machine.
        /// </summary>
        public void Shutdown()
        {
            UIManagerMenu.instance.ShowMenuLobby(0);  // Show the menu
            NetworkManager.Singleton.Shutdown();
        }

        // ============================= UTILS ==============================================================================

        /// <summary>
        /// Not implemented. Should check port availability.
        /// </summary>
        private bool IsPortAvailable(int port)
        {
            // POTENTIALLY IMPLEMENT PORT AVAILABILITY CHECK
            return true;
        }

#if UNITY_EDITOR
        //To fight an error that happens when host exits the player mode with clients connected. Disconnect callback is being fired on behalf of the client
        private void OnPlayModeStateChanged(PlayModeStateChange state)
        {
            if (state == PlayModeStateChange.ExitingPlayMode)
            {
                exitingPlayerMode = true;
            }
        }
#endif
    }
}
