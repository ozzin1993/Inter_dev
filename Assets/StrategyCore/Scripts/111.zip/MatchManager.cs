using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace StrategyCore
{
    // ============================= WAVE ENTRY ==
    [Serializable]
    public class WaveEntry
    {
        public Unit unitToSpawn;
        [Tooltip("Количество юнитов данного типа в волне")]
        public int count = 1;
    }

    // ============================= TEAM CONFIG ==
    // Полный конфиг одной команды. Раньше был отдельным компонентом UnitWaveSpawner —
    // свёрнут сюда, чтобы уменьшить число объектов/точек входа. Всё настраивается в Inspector.
    [Serializable]
    public class TeamWaveConfig
    {
        [Tooltip("Индекс игрока-владельца юнитов этой команды (A обычно 0, B обычно 1).")]
        public int ownerPlayer = 0;

        [Header("Состав волны")]
        [Tooltip("Типы юнитов и их количество в одной волне.")]
        public WaveEntry[] waveComposition;
        [Tooltip("Задержка между спавном юнитов внутри волны, сек. 0 — одновременно (риск NavMesh overlap).")]
        public float spawnDelay = 0f;
        [Tooltip("Радиус разброса точки спавна (Unit.Spawn ищет свободное место). Реком. 1–2.")]
        public float spawnRadius = 1f;

        [Header("Точки")]
        [Tooltip("Точка спавна юнитов команды.")]
        public Transform spawnPoint;
        [Tooltip("Запасная цель, если Lane у менеджера не задана.")]
        public Transform targetPoint;

        [Header("Строй (FormationMarch)")]
        [Tooltip("Вести волну единым квадратом. Выкл — каждый юнит сам AttackMove на цель.")]
        public bool useFormationMarch = true;
        [Tooltip("Радиус обнаружения врага вокруг центра группы (бой).")]
        public float detectionRadius = 8f;
        [Tooltip("Сколько секунд без врага ждать перед пересборкой строя после боя.")]
        public float regroupDebounce = 1.5f;
        [Tooltip("Период опроса состояния строя, сек.")]
        public float formationPollInterval = 0.5f;
        [Tooltip("Дистанция до цели, считающаяся прибытием. Для ЗАЩИТЫ — запас сверх полуразмера строя (порог считается динамически от числа юнитов); для атаки/марша — абсолютное значение.")]
        public float arrivalDistance = 3f;
        [Tooltip("Расстояние между слотами строя.")]
        public float slotSpacing = 2f;

        [Header("Способности")]
        [Tooltip("Персистентный юнит-кастер команды (герой/главное здание) для активируемых способностей " +
                 "центральной нижней таблицы. Владелец юнита должен совпадать с ownerPlayer. " +
                 "Список способностей задаётся ниже (centralAbilities) — MatchManager сам пропишет их в " +
                 "abilities[] этого юнита при старте; добавлять через SCEditor не нужно.")]
        public Unit abilityCaster;

        [Tooltip("Способности центральной нижней таблицы команды по порядку. Единый источник: MatchManager " +
                 "прописывает этот список в abilities[] кастера (для штатного каста — кулдаун/мана/сеть), " +
                 "а UI берёт отсюда же иконки. Иконка — из Ability.icon[0]. Поддержаны Active-способности.")]
        public List<Ability> centralAbilities = new List<Ability>();
    }

    // ============================= POINT TOWER CONFIG ==
    // Конфиг одной перестраиваемой точки. Начальный владелец задаётся в самой PointOfInterest
    // (teamAffiliation) — здесь только префаб башни для отстройки и задержка.
    [Serializable]
    public class PointTowerConfig
    {
        [Tooltip("Точка линии, башня которой может уничтожаться и отстраиваться (Defence1/Defence2/Centre). Замки не добавлять.")]
        public PointOfInterest point;
        [Tooltip("Префаб башни для отстройки после захвата (спавнится под захватившей командой).")]
        public Unit towerPrefab;
        [Tooltip("Задержка отстройки башни после захвата, сек. > 0, чтобы тело успело освободить точку спавна.")]
        public float rebuildDelay = 1f;
    }

    // ============================= MANAGER ==
    /// <summary>
    /// Единый серверный оркестратор матча (MVP: 2 команды A/B, одна линия). Берёт на себя
    /// максимум: спавн волн обеих команд, темп, Lane-таргетинг, отстройку башен точек. Спавнеры как
    /// отдельные компоненты упразднены — их конфиг свёрнут в поля teamA/teamB (Inspector).
    ///
    /// Победа НЕ дублируется — штатная GameManager.specificUnitsDead (NetID баз + winningTeam).
    /// Перестраиваемые башни точек тоже управляются отсюда: подписка на OnDie стартовых башен,
    /// при гибели точка переходит сопернику и через задержку отстраивается новая (модель «смерть + отстройка»).
    /// </summary>
    public partial class MatchManager : MonoBehaviour
    {
        [Header("Команды")]
        [Tooltip("Команда A (обычно игрок 0).")]
        [SerializeField] TeamWaveConfig teamA;
        [Tooltip("Команда B (обычно игрок 1).")]
        [SerializeField] TeamWaveConfig teamB;

        [Header("Линия")]
        [Tooltip("Линия точек интереса. Если задана — цель волн/команд = Lane динамически; иначе targetPoint конфига.")]
        [SerializeField] Lane lane;

        [Header("Точки с отстройкой башен")]
        [Tooltip("Перестраиваемые точки линии (Defence1/Defence2/Centre). Для каждой — префаб башни после " +
                 "отстройки и задержка. Замки сюда НЕ добавлять: они не перестраиваются. " +
                 "Начальный владелец каждой точки задаётся в самой PointOfInterest (teamAffiliation). " +
                 "unitRef точки должен указывать на её стартовую башню/замок в сцене.")]
        [SerializeField] PointTowerConfig[] rebuildablePoints;

        [Header("Темп волн")]
        [Tooltip("Задержка до первой волны после старта матча, сек.")]
        [SerializeField] float firstWaveDelay = 5f;
        [Tooltip("Интервал между волнами, сек. Единый для обеих команд.")]
        [SerializeField] float waveInterval = 30f;

        [Header("Экономика волн")]
        [Tooltip("Ассет ресурса «Золото» (standard). Списывается за всю волну перед спавном; " +
                 "награда за убийство врага начисляется штатно через Unit.resourceReward.")]
        [SerializeField] Resource goldResource;
        [Tooltip("Ассет ресурса «Лидерство» (limited). Кап карты = лимит этого ресурса в GameResources " +
                 "(пользователь задаёт его как пул волны × 3). Живые юниты занимают лидерство сами через Unit.resourceCost.")]
        [SerializeField] Resource leadershipResource;
        [Tooltip("Бюджет лидерства на одну волну. Суммарная стоимость состава не должна его превышать. " +
                 "Дефолт условный — итоговое значение задаёт пользователь.")]
        [SerializeField] int waveLeadershipPool = 100;

        /// <summary>Ассет ресурса «Золото» (для UI: читать цену из prefab.resourceCost). Единый источник ссылки.</summary>
        public Resource GoldResource => goldResource;
        /// <summary>Ассет ресурса «Лидерство» (для UI: читать цену из prefab.resourceCost). Единый источник ссылки.</summary>
        public Resource LeadershipResource => leadershipResource;

        /// <summary>Единственный экземпляр. Единый источник Lane-таргетинга и спавна для волн и UI-команд.</summary>
        public static MatchManager instance;

        /// <summary>Вызывается после спавна каждого юнита волны. Параметры: индекс команды (0=A, 1=B), юнит.</summary>
        public event Action<int, Unit> OnUnitSpawned;

        /// <summary>Состав волны команды изменился (параметр — индекс команды 0=A, 1=B). Для перерисовки UI конструктора.</summary>
        public event Action<int> OnWaveCompositionChanged;

        // ======================== СПИСОК ЮНИТОВ ========================
        // Активные корутины move→hold для защиты каждой команды (0=A, 1=B). Отменяются при новой команде.
        readonly Coroutine[] defenceHoldCoroutines = new Coroutine[2];

        // Живые боевые юниты (UnitType.Unit) каждой команды. Обновляются при спавне волны и OnDie.
        // На клиенте не обновляются (спавн серверный) — GetGroupUnits на клиенте использует FindObjectsByType.
        List<Unit>[] teamUnits;

        // ======================== «ПРИЗЫВ К ОРУЖИЮ» ========================
        // Снимок состава ПОСЛЕДНЕЙ фактически заспавненной волны каждой команды (prefab → count).
        // Обновляется в SpawnWave только при успешном спавне. Источник для способности CallToArmsActive.
        readonly List<WaveEntry>[] lastWaveComposition = new List<WaveEntry>[2] { new List<WaveEntry>(), new List<WaveEntry>() };

        // Призванные способностью юниты (временное ополчение) каждой команды. НЕ входят в teamUnits,
        // поэтому не попадают под команды Атака/Защита. Удаляются по OnDie. Используются для переотдачи
        // команды при потере точки (ReissueSummonedCommand). Только для не слушающих общих приказов.
        readonly List<Unit>[] summonedUnits = new List<Unit>[2] { new List<Unit>(), new List<Unit>() };

        // ======================== ХРАНИМЫЕ ЦЕЛИ И РЕЖИМ КОМАНДЫ ========================

        // Текущие точки атаки и защиты для каждой команды (0=A, 1=B). Обновляются через RefreshTargetPoints.
        Vector2[] currentAttackPoint  = new Vector2[2];
        Vector2[] currentDefencePoint = new Vector2[2];

        // Текущий режим команды для каждой команды. None — режим не выбран (волны идут по умолчанию).
        BottomTableAction[] currentCommand = new BottomTableAction[2];

        // ======================== LIFECYCLE ========================

        void Awake()
        {
            // Доступен и на клиенте (UI-команды читают цели/состав через него); сами волны — только сервер.
            if (instance != null && instance != this) { Destroy(this); return; }
            instance = this;

            teamUnits = new List<Unit>[2] { new List<Unit>(), new List<Unit>() };

            // Единый источник способностей центральной таблицы: список из Inspector прописываем в abilities[]
            // кастера ДО его инициализации (Unit.Initialize → InitializeAbilities идёт по OnGameStart, т.е. позже
            // Awake). Делается на всех пирах — данные из общего Inspector детерминированы, индексы каста совпадут
            // на сервере и клиенте (это конфиг, не игровое действие; правило 6 здесь не применяется).
            AssignCasterAbilities(teamA);
            AssignCasterAbilities(teamB);
        }

        // Прописывает способности центральной таблицы в abilities[] кастера команды (если оба заданы).
        // Кулдауны/уровни построит штатная Unit.InitializeAbilities при инициализации кастера (правило 2).
        void AssignCasterAbilities(TeamWaveConfig cfg)
        {
            if (cfg == null || cfg.abilityCaster == null) return;
            cfg.abilityCaster.abilities = (cfg.centralAbilities != null)
                ? cfg.centralAbilities.ToArray()
                : new Ability[0];
        }

        void OnDestroy()
        {
            foreach (Unit tower in hookedTowers.Keys)
                if (tower != null) tower.OnDie -= HandleTowerDie;
            hookedTowers.Clear();
            if (instance == this) instance = null;
        }

        void Start()
        {
            if (NetworkConnectionHandler.isClient) return;

            ValidateSetup();

            if (rebuildablePoints != null)
            {
                foreach (PointTowerConfig cfg in rebuildablePoints)
                {
                    if (cfg == null || cfg.point == null) continue;
                    HookTower(cfg.point.unitRef, cfg);
                }
            }

            StartCoroutine(WaveLoop());
        }

        // ======================== ДОСТУП ДЛЯ UI ========================

        /// <summary>Конфиг команды по индексу: 0 = A, иначе B.</summary>
        public TeamWaveConfig Team(int index) => index == 0 ? teamA : teamB;

        // ======================== LANE-ТАРГЕТИНГ (единый источник) ========================

        /// <summary>Цель атаки для игрока: следующая вражеская точка линии. Vector2.zero — если линии/цели нет.</summary>
        public Vector2 AttackTarget(int player)
        {
            if (lane == null) return Vector2.zero;
            return lane.NextAttackTarget(SlotManager.instance.playerTeam[player]);
        }

        /// <summary>Цель обороны для игрока: самая передовая своя точка линии. Vector2.zero — если своих точек нет.</summary>
        public Vector2 DefenceTarget(int player)
        {
            if (lane == null) return Vector2.zero;
            return lane.FrontmostOwnedPoint(SlotManager.instance.playerTeam[player]);
        }

        // ======================== ВСПОМОГАТЕЛЬНЫЕ: ИМЕНА ТОЧЕК ДЛЯ ЛОГОВ ========================

        // PointOfInterest текущей цели атаки для игрока. null — если Lane не задана или нет цели.
        PointOfInterest AttackTargetPOI(int player)
        {
            if (lane == null) return null;
            return lane.NextAttackTargetPoint(SlotManager.instance.playerTeam[player]);
        }

        // PointOfInterest текущей цели защиты для игрока. null — если Lane не задана или нет цели.
        PointOfInterest DefenceTargetPOI(int player)
        {
            if (lane == null) return null;
            return lane.FrontmostOwnedPointPoint(SlotManager.instance.playerTeam[player]);
        }

        // Читаемое имя точки для лога. null → "нет".
        static string POIName(PointOfInterest poi) => poi != null ? poi.name : "нет";

        // ======================== КОМАНДЫ ЮНИТАМ ========================

        /// <summary>
        /// Отправить всех живых боевых юнитов команды в атаку (следующая вражеская точка линии).
        /// Запоминает режим: при следующем спавне волны или гибели башни команда переотдаётся автоматически.
        /// </summary>
        public void SendAttackCommand(int teamIndex)
        {
            TeamWaveConfig cfg = Team(teamIndex);
            if (cfg == null) return;
            int player = cfg.ownerPlayer;

            PointOfInterest attackPOI  = AttackTargetPOI(player);
            Vector2 newAttackPoint = attackPOI != null ? attackPOI.Position2D : Vector2.zero;
            if (newAttackPoint != currentAttackPoint[teamIndex])
                Debug.Log($"[MatchManager] Точка атаки команды {teamIndex} изменилась → {POIName(attackPOI)}.");
            currentAttackPoint[teamIndex] = newAttackPoint;
            currentCommand[teamIndex] = BottomTableAction.Attack;

            List<Unit> units = GetGroupUnits(teamIndex);
            Debug.Log($"[MatchManager] АТАКА: команда {teamIndex} (player={player}), " +
                      $"юнитов={units.Count}, цель={POIName(attackPOI)}, " +
                      $"режим={( NetworkConnectionHandler.isClient ? "клиент(AttackMove)" : "сервер(FormationMarch)" )}.");
            if (units.Count == 0) return;

            Vector2 target = currentAttackPoint[teamIndex];
            if (target == Vector2.zero) return;

            if (NetworkConnectionHandler.isClient)
            {
                for (int i = 0; i < units.Count; i++)
                    units[i].AttackMove(target);
                return;
            }

            Func<Vector2> targetDelegate = lane != null ? () => AttackTarget(player) : (Func<Vector2>)null;
            StopFormationsForOwner(player);
            FormationMarch.Begin(
                units, target, player,
                cfg.detectionRadius, cfg.regroupDebounce, cfg.formationPollInterval, cfg.arrivalDistance,
                cfg.slotSpacing, targetDelegate);
        }

        /// <summary>
        /// Отправить всех живых боевых юнитов команды в режим Hold (стоят на месте, атакуют в радиусе).
        /// Запоминает режим: при следующем спавне волны или гибели башни команда переотдаётся автоматически.
        /// </summary>
        public void SendDefenceCommand(int teamIndex)
        {
            TeamWaveConfig cfg = Team(teamIndex);
            if (cfg == null) return;
            int player = cfg.ownerPlayer;

            PointOfInterest defencePOI  = DefenceTargetPOI(player);
            Vector2 newDefencePoint = defencePOI != null ? defencePOI.Position2D : Vector2.zero;
            if (newDefencePoint != currentDefencePoint[teamIndex])
                Debug.Log($"[MatchManager] Точка защиты команды {teamIndex} изменилась → {POIName(defencePOI)}.");
            currentDefencePoint[teamIndex] = newDefencePoint;
            currentCommand[teamIndex] = BottomTableAction.Defence;

            List<Unit> units = GetGroupUnits(teamIndex);
            Debug.Log($"[MatchManager] ЗАЩИТА: команда {teamIndex} (player={player}), " +
                      $"юнитов={units.Count}, точка={POIName(defencePOI)}.");
            if (units.Count == 0) return;

            Vector2 target = currentDefencePoint[teamIndex];
            if (target == Vector2.zero) return;

            if (!NetworkConnectionHandler.isClient)
            {
                StopFormationsForOwner(player);
                // Отменяем предыдущую корутину холда, если она ещё ждёт прибытия.
                if (defenceHoldCoroutines[teamIndex] != null)
                {
                    StopCoroutine(defenceHoldCoroutines[teamIndex]);
                    defenceHoldCoroutines[teamIndex] = null;
                }
                // Идём к точке защиты; Hold выдаётся по прибытии.
                // Раскладка по слотам штатным ComputeFormation — чтобы юниты не боролись за одну точку
                // (допуск прибытия ассета 0.1 м + carving-обстакл вставшего юнита = вечная толкучка).
                units.RemoveAll(u => u == null || u.dead);
                if (units.Count == 0) return;
                if (PlayerControl.instance != null)
                {
                    List<Vector2> dests = PlayerControl.instance.ComputeFormation(
                        units, new Vector3(target.x, 0f, target.y));
                    for (int i = 0; i < units.Count && i < dests.Count; i++)
                        units[i].Move(dests[i]);
                }
                else
                {
                    // Фоллбэк (headless-сервер без PlayerControl): прежнее поведение — все на точку.
                    for (int i = 0; i < units.Count; i++)
                        units[i].Move(target);
                }
                // ВРЕМЕННО отключено: Hold по прибытии (по просьбе пользователя, 2026-06-10).
                // defenceHoldCoroutines[teamIndex] = StartCoroutine(
                //     HoldOnArrival(teamIndex, units, target,
                //         GroupArrivalThreshold(units, Team(teamIndex).arrivalDistance)));
            }
            else
            {
                // Клиент: движение к точке (сервер выдаст Hold по прибытии).
                for (int i = 0; i < units.Count; i++)
                    if (units[i] != null) units[i].AttackMove(target);
            }
        }

        /// <summary>
        /// Переотдать одному юниту текущую команду его команды (Атака/Защита).
        /// Нужна для возврата юнита к маршу/обороне после авто-каста (см. AutoAbilityUser).
        /// Серверо-авторитетно. Цель берётся «вживую» из Lane (единый источник истины),
        /// поэтому актуальна даже после смены владельца точек. Если у команды нет активного
        /// режима (None) или цели нет — ничего не делает.
        /// </summary>
        public void ReissueCurrentCommand(Unit unit)
        {
            if (NetworkConnectionHandler.isClient) return;
            if (unit == null || unit.dead) return;

            int teamIndex = TeamIndexOfOwner(unit.owner);
            if (teamIndex < 0) return;

            int player = Team(teamIndex).ownerPlayer;
            switch (currentCommand[teamIndex])
            {
                case BottomTableAction.Attack:
                    Vector2 atk = AttackTarget(player);
                    if (atk != Vector2.zero) unit.AttackMove(atk);
                    break;
                case BottomTableAction.Defence:
                    Vector2 def = DefenceTarget(player);
                    if (def != Vector2.zero) unit.Move(def);
                    break;
                // None — переотдавать нечего.
            }
        }

        // Индекс команды (0=A, 1=B) по игроку-владельцу. -1, если ни одна команда не владеет этим игроком.
        int TeamIndexOfOwner(int player)
        {
            if (teamA != null && teamA.ownerPlayer == player) return 0;
            if (teamB != null && teamB.ownerPlayer == player) return 1;
            return -1;
        }

        /// <summary>
        /// Боевые юниты команды игрока — ТОТ ЖЕ список, что используется для команд Атака/Защита
        /// (GetGroupUnits). Пусто, если игрок не владеет ни одной командой.
        /// </summary>
        public List<Unit> GetCommandUnitsForPlayer(int player)
        {
            int teamIndex = TeamIndexOfOwner(player);
            if (teamIndex < 0) return new List<Unit>();
            return GetGroupUnits(teamIndex);
        }

        // Динамический порог прибытия группы: запас из конфига (arrivalDistance) + полуразмер
        // строя ComputeFormation (√N × макс. unitRadius). Считается один раз при выдаче команды.
        static float GroupArrivalThreshold(List<Unit> units, float margin)
        {
            int n = 0;
            float maxRadius = 0f;
            for (int i = 0; i < units.Count; i++)
            {
                Unit u = units[i];
                if (u == null || u.dead) continue;
                n++;
                if (u.unitRadius > maxRadius) maxRadius = u.unitRadius;
            }
            if (n == 0) return margin;
            return margin + Mathf.Sqrt(n) * maxRadius;
        }

        // Корутина: ждёт, пока все живые юниты команды не окажутся рядом с точкой,
        // затем выдаёт им Hold. Самоотключается, если все юниты погибли до прибытия.
        IEnumerator HoldOnArrival(int teamIndex, List<Unit> units, Vector2 target, float arrivalThreshold)
        {
            while (true)
            {
                yield return new WaitForSeconds(0.2f);

                bool anyAlive = false;
                bool anyFar   = false;
                for (int i = 0; i < units.Count; i++)
                {
                    Unit u = units[i];
                    if (u == null || u.dead) continue;
                    anyAlive = true;
                    Vector3 pos = u.transform.position;
                    if (Vector2.Distance(new Vector2(pos.x, pos.z), target) > arrivalThreshold)
                        anyFar = true;
                }

                if (!anyAlive)   // все погибли — холд не нужен
                {
                    defenceHoldCoroutines[teamIndex] = null;
                    yield break;
                }
                if (!anyFar) break; // все добрались до точки
            }

            defenceHoldCoroutines[teamIndex] = null;
            Debug.Log($"[MatchManager] ХОЛД: юниты команды {teamIndex} прибыли в точку защиты, занимаем холд.");
            for (int i = 0; i < units.Count; i++)
            {
                Unit u = units[i];
                if (u != null && !u.dead) u.Hold();
            }
        }

        // Живые боевые юниты команды. Сервер — из teamUnits; клиент — FindObjectsByType.
        List<Unit> GetGroupUnits(int teamIndex)
        {
            if (!NetworkConnectionHandler.isClient)
                return new List<Unit>(teamUnits[teamIndex]);

            int player = Team(teamIndex).ownerPlayer;
            List<Unit> result = new List<Unit>();
            Unit[] all = UnityEngine.Object.FindObjectsByType<Unit>(FindObjectsSortMode.None);
            for (int i = 0; i < all.Length; i++)
            {
                Unit u = all[i];
                if (u == null || u.dead || u.owner != player || u.unitType != UnitType.Unit) continue;
                // Призванных, НЕ слушающих общих приказов, исключаем. Слушающие (obeyCommands) — как обычные юниты.
                SummonedUnit s = u.GetComponent<SummonedUnit>();
                if (s != null && !s.obeyCommands) continue;
                result.Add(u);
            }
            return result;
        }

        // Обновить хранимые точки атаки и защиты для обеих команд.
        void RefreshTargetPoints()
        {
            for (int i = 0; i < 2; i++)
            {
                TeamWaveConfig cfg = Team(i);
                if (cfg == null) continue;
                int player = cfg.ownerPlayer;

                PointOfInterest newAttackPOI  = AttackTargetPOI(player);
                PointOfInterest newDefencePOI = DefenceTargetPOI(player);
                Vector2 newAttack  = newAttackPOI  != null ? newAttackPOI.Position2D  : Vector2.zero;
                Vector2 newDefence = newDefencePOI != null ? newDefencePOI.Position2D : Vector2.zero;

                if (newAttack  != currentAttackPoint[i])
                    Debug.Log($"[MatchManager] RefreshTargetPoints: точка атаки команды {i} " +
                              $"→ {POIName(newAttackPOI)}.");
                if (newDefence != currentDefencePoint[i])
                    Debug.Log($"[MatchManager] RefreshTargetPoints: точка защиты команды {i} " +
                              $"→ {POIName(newDefencePOI)}.");

                currentAttackPoint[i]  = newAttack;
                currentDefencePoint[i] = newDefence;
            }
        }

        // Остановить все FormationMarch указанного владельца (чтобы не конфликтовали с новой командой).
        void StopFormationsForOwner(int player)
        {
            if (NetworkConnectionHandler.isClient) return;
            FormationMarch[] all = UnityEngine.Object.FindObjectsByType<FormationMarch>(FindObjectsSortMode.None);
            for (int i = 0; i < all.Length; i++)
                if (all[i] != null && all[i].OwnerPlayer == player)
                    all[i].Stop();
        }

        // ======================== «ПРИЗЫВ К ОРУЖИЮ» (повторная волна ополчения) ========================

        /// <summary>
        /// Сервер: призвать дубль последней фактически заспавненной волны команды кастера вне очереди.
        /// Призванные юниты: живут lifetime сек (LifetimeUnit), не тратят лидерство/золото (компенсация),
        /// не получают обычных команд (маркер SummonedUnit), обороняют передовую свою точку (DefenceTarget).
        /// Точка входа способности CallToArmsActive (вся логика централизована здесь, правило 5).
        /// </summary>
        public void SummonLastWave(int castingPlayer, float lifetime,
                                   bool obeyCommands, BottomTableAction defaultCommand,
                                   VFXReferencer vfx, AudioClip sound, float soundVolume)
        {
            if (NetworkConnectionHandler.isClient) return; // спавн/жизнь/команды — только сервер (правило 6)

            int teamIndex = TeamIndexOfOwner(castingPlayer);
            if (teamIndex < 0) { Debug.LogWarning($"[MatchManager] Призыв к Оружию: игрок {castingPlayer} не владеет командой."); return; }

            TeamWaveConfig cfg = Team(teamIndex);
            if (cfg == null || cfg.spawnPoint == null)
            { Debug.LogWarning($"[MatchManager] Призыв к Оружию: команда {teamIndex} без конфига/точки спавна."); return; }

            List<WaveEntry> comp = lastWaveComposition[teamIndex];
            if (comp == null || comp.Count == 0)
            { Debug.Log($"[MatchManager] Призыв к Оружию: у команды {teamIndex} ещё не было волн — призыв пропущен."); return; }

            // Презентация один раз в точке спавна. Серверо-онли (как и весь каст Active) — на чистых клиентах
            // не видна/не слышна, как и VFX FlameCloakActive (полная сетевая синхронизация — отдельная задача).
            PlaySummonFx(cfg.spawnPoint, vfx, sound, soundVolume);

            int summoned = 0;
            foreach (WaveEntry entry in comp)
            {
                if (entry == null || entry.unitToSpawn == null) continue;
                for (int i = 0; i < entry.count; i++)
                {
                    Unit u = Unit.Spawn(entry.unitToSpawn, cfg.spawnPoint.position, 0f, cfg.ownerPlayer, cfg.spawnRadius);
                    if (u == null)
                    {
                        Debug.LogWarning($"[MatchManager] Призыв к Оружию: не удалось заспавнить {entry.unitToSpawn.name} (точка занята?).");
                        continue;
                    }

                    // Маркер «призван» (рантайм-настройки). obeyCommands решает, попадает ли юнит под общие приказы.
                    SummonedUnit mark = u.GetComponent<SummonedUnit>();
                    if (mark == null) mark = u.gameObject.AddComponent<SummonedUnit>();
                    mark.obeyCommands = obeyCommands;
                    mark.command = defaultCommand;

                    // Время жизни — штатный LifetimeUnit (по истечении зовёт Unit.Die). Префаб волны его не имеет.
                    ApplySummonLifetime(u, lifetime);

                    // Компенсация лидерства/прочих Limited-ресурсов (чтобы призыв был «бесплатным» по ТЗ).
                    CompensateSummonLimitedCost(u);

                    int capt = teamIndex;
                    if (obeyCommands)
                    {
                        // Слушает общие приказы → ведём как обычного юнита команды: в teamUnits (его увидят
                        // SendAttack/Defence и переотдача при волне/гибели башни), удаление по OnDie как у волны.
                        teamUnits[teamIndex].Add(u);
                        u.OnDie += (du, _, _, _) => { teamUnits[capt].Remove(du); };
                        // Сразу подхватываем текущий режим команды (None → idle, как обычный новый юнит).
                        ReissueCurrentCommand(u);
                    }
                    else
                    {
                        // Не слушает общих приказов → отдельный список, фиксированная команда (Защита/Атака).
                        summonedUnits[teamIndex].Add(u);
                        u.OnDie += (du, _, _, _) => { summonedUnits[capt].Remove(du); };
                        IssueSummonedCommand(u, cfg.ownerPlayer, defaultCommand);
                    }

                    summoned++;
                }
            }
            Debug.Log($"[MatchManager] Призыв к Оружию: команда {teamIndex} (player={cfg.ownerPlayer}), призвано {summoned} юнитов, " +
                      $"жизнь {lifetime} с, общие приказы={(obeyCommands ? "слушают" : "нет (" + defaultCommand + ")")}.");
        }

        // Навесить штатный LifetimeUnit на призванного. Префабы волны его не имеют, поэтому Unit.Initialize
        // его не проинициализировал → вызываем Initialize() вручную (подпишет Tick и OnDie). Если компонент
        // уже был на префабе — ассет проинициализировал сам, не трогаем (во избежание двойной подписки).
        void ApplySummonLifetime(Unit u, float lifetime)
        {
            if (u == null || lifetime <= 0f) return;
            if (u.GetComponent<LifetimeUnit>() != null) return; // уже инициализирован ассетом
            LifetimeUnit lt = u.gameObject.AddComponent<LifetimeUnit>();
            lt.lifespan = lifetime;
            if (GameManager.instance != null) lt.Initialize();
            else Debug.LogWarning("[MatchManager] Призыв к Оружию: GameManager.instance == null — LifetimeUnit не инициализирован.");
        }

        // «Бесплатность» призыва по Limited-ресурсам (лидерство): ассет в Unit.Initialize занял ресурс
        // (decrease=true → usage += value). Сразу возвращаем (decrease=false → usage −= value): нетто-ноль при жизни.
        // На смерти ассет вернёт ресурс ещё раз (Unit.Die) → подписываемся и зеркалим (повторно занимаем),
        // чтобы суммарный usage не изменился ни при жизни, ни при смерти. Серверо-авторитетно (calledByServer=true).
        void CompensateSummonLimitedCost(Unit u)
        {
            if (u == null || u.resourceCost == null || GameResources.instance == null) return;

            ResourceWrapper[] costs = u.resourceCost;
            int owner = u.owner;

            for (int i = 0; i < costs.Length; i++)
            {
                ResourceWrapper rw = costs[i];
                if (rw == null || rw.type == null || !rw.type.limited) continue;
                GameResources.instance.ChangeAmount(owner, rw, 1, false, true); // вернуть занятое ассетом при спавне
            }

            u.OnDie += (du, _, _, _) =>
            {
                if (GameResources.instance == null) return;
                for (int i = 0; i < costs.Length; i++)
                {
                    ResourceWrapper rw = costs[i];
                    if (rw == null || rw.type == null || !rw.type.limited) continue;
                    GameResources.instance.ChangeAmount(owner, rw, 1, true, true); // отменить возврат ассета на смерти
                }
            };
        }

        // Выдать призванному (не слушающему общих приказов) его фиксированную команду:
        // Attack → AttackMove на следующую вражескую точку, иначе Defence → Move на передовую свою точку.
        void IssueSummonedCommand(Unit u, int player, BottomTableAction command)
        {
            if (NetworkConnectionHandler.isClient) return;
            if (u == null || u.dead) return;

            if (command == BottomTableAction.Attack)
            {
                Vector2 atk = AttackTarget(player);
                if (atk != Vector2.zero) u.AttackMove(atk);
            }
            else // Defence (и любой иной режим трактуем как оборону)
            {
                Vector2 def = DefenceTarget(player);
                if (def != Vector2.zero) u.Move(def);
            }
        }

        // Переотдать команду всем живым призванным из отдельного списка (фронт сместился при потере точки →
        // Attack/Defence пересчитают цель вживую). Каждому — его собственная фиксированная команда (маркер).
        void ReissueSummonedCommand()
        {
            if (NetworkConnectionHandler.isClient) return;
            for (int t = 0; t < 2; t++)
            {
                TeamWaveConfig cfg = Team(t);
                if (cfg == null) continue;
                List<Unit> list = summonedUnits[t];
                for (int i = 0; i < list.Count; i++)
                {
                    Unit u = list[i];
                    if (u == null || u.dead) continue;
                    SummonedUnit mark = u.GetComponent<SummonedUnit>();
                    IssueSummonedCommand(u, cfg.ownerPlayer, mark != null ? mark.command : BottomTableAction.Defence);
                }
            }
        }

        // Презентация призыва (VFX + звук) один раз в точке спавна. Оба элемента опциональны.
        void PlaySummonFx(Transform at, VFXReferencer vfx, AudioClip sound, float soundVolume)
        {
            if (at == null) return;
            // VFX: спавним экземпляр в точке спавна. По конвенции ассета VFX сам себя уничтожает после проигрывания.
            if (vfx != null) Instantiate(vfx.gameObject, at.position, at.rotation);
            // Звук: штатный SoundFXManager. mixerGroup не задаём (группа по умолчанию).
            if (sound != null && SoundFXManager.instance != null)
                SoundFXManager.instance.PlaySoundClip(sound, at, soundVolume, null);
        }

        // ======================== ВОЛНЫ ========================

        IEnumerator WaveLoop()
        {
            yield return new WaitUntil(() => SlotManager.instance != null && SlotManager.instance.gameOn);
            Debug.Log("[MatchManager] Матч начался — запускаем волны.");

            if (firstWaveDelay > 0f)
            {
                Debug.Log($"[MatchManager] Ожидаем первую волну {firstWaveDelay} сек.");
                yield return new WaitForSeconds(firstWaveDelay);
            }

            int waveNumber = 1;
            while (true)
            {
                Debug.Log($"[MatchManager] Волна #{waveNumber} — спавним обе команды.");
                StartCoroutine(SpawnWave(teamA, 0));
                StartCoroutine(SpawnWave(teamB, 1));
                waveNumber++;
                yield return new WaitForSeconds(waveInterval);
            }
        }

        IEnumerator SpawnWave(TeamWaveConfig cfg, int teamIndex)
        {
            if (cfg == null) yield break;
            if (cfg.spawnPoint == null)
            {
                Debug.LogWarning($"[MatchManager] Команда {teamIndex}: spawnPoint не назначен.");
                yield break;
            }
            if (cfg.targetPoint == null && lane == null)
            {
                Debug.LogWarning($"[MatchManager] Команда {teamIndex}: нет ни Lane, ни targetPoint.");
                yield break;
            }
            if (cfg.waveComposition == null || cfg.waveComposition.Length == 0)
                yield break;

            // ── Экономика волны (серверная проверка перед спавном) ──
            // Все проверки ДО спавна и ДО любых списаний. При провале любой — волна пропускается
            // целиком (ждём следующий интервал). Цены берутся из штатного Unit.resourceCost префабов.
            int leadershipSum = WaveResourceSum(cfg.waveComposition, leadershipResource);
            int goldSum       = WaveResourceSum(cfg.waveComposition, goldResource);

            // 1) Бюджет состава ≤ пул волны (страховка — UI не должен такое допускать).
            if (leadershipSum > waveLeadershipPool)
            {
                Debug.LogWarning($"[MatchManager] Команда {teamIndex}: состав требует {leadershipSum} лидерства " +
                                 $"при пуле волны {waveLeadershipPool} — волна пропущена.");
                yield break;
            }

            // 2) Лидерство волны влезает в остаток капа карты (часть лимита уже занята живыми юнитами).
            if (leadershipResource != null &&
                !GameResources.instance.CheckAmount(cfg.ownerPlayer, new ResourceWrapper(leadershipResource, leadershipSum)))
            {
                Debug.LogWarning($"[MatchManager] Команда {teamIndex}: лидерство волны ({leadershipSum}) " +
                                 "не влезает в кап карты — волна пропущена.");
                yield break;
            }

            // 3) Золота хватает на весь состав.
            if (goldResource != null &&
                !GameResources.instance.CheckAmount(cfg.ownerPlayer, new ResourceWrapper(goldResource, goldSum)))
            {
                Debug.LogWarning($"[MatchManager] Команда {teamIndex}: не хватает золота ({goldSum}) на волну — волна пропущена.");
                yield break;
            }

            // 4) Списываем золото за всю волну одним вызовом. Для standard decrease=true вычитает;
            //    calledByServer=true → штатный авто-синк клиентам (ResourceSendAdd).
            if (goldResource != null && goldSum > 0)
            {
                Debug.Log($"[MatchManager] Команда {teamIndex}: ChangeAmount — игрок={cfg.ownerPlayer}, " +
                          $"ресурс={goldResource.displayName}, сумма={goldSum}, multiplier=1, decrease=true, calledByServer=true.");
                GameResources.instance.ChangeAmount(cfg.ownerPlayer, new ResourceWrapper(goldResource, goldSum), 1, true, true);
            }

            // Единый источник цели — AttackTarget (тот же путь, что у команд UI).
            Func<Vector2> targetDelegate = (lane != null) ? () => AttackTarget(cfg.ownerPlayer) : (Func<Vector2>)null;
            Vector2 attackTarget = (targetDelegate != null) ? targetDelegate() : Vector2.zero;
            if (attackTarget == Vector2.zero && cfg.targetPoint != null)
                attackTarget = new Vector2(cfg.targetPoint.position.x, cfg.targetPoint.position.z);

            List<Unit> waveUnits = new List<Unit>();
            // Счётчик фактически заспавненных по префабам — для снимка последней волны («Призыв к Оружию»).
            Dictionary<Unit, int> spawnedCounts = new Dictionary<Unit, int>();
            string attackTargetName = lane != null
                ? POIName(AttackTargetPOI(cfg.ownerPlayer))
                : (cfg.targetPoint != null ? cfg.targetPoint.name : "нет");
            Debug.Log($"[MatchManager] Спавн волны команды {teamIndex} (player={cfg.ownerPlayer}): " +
                      $"цель={attackTargetName}, точка спавна={cfg.spawnPoint.position}.");

            foreach (WaveEntry entry in cfg.waveComposition)
            {
                if (entry == null || entry.unitToSpawn == null) continue;
                for (int i = 0; i < entry.count; i++)
                {
                    Unit spawned = Unit.Spawn(entry.unitToSpawn, cfg.spawnPoint.position, 0f, cfg.ownerPlayer, cfg.spawnRadius);
                    if (spawned != null)
                    {
                        waveUnits.Add(spawned);
                        // Учёт фактически заспавненного типа (для снимка последней волны).
                        spawnedCounts.TryGetValue(entry.unitToSpawn, out int prev);
                        spawnedCounts[entry.unitToSpawn] = prev + 1;
                        // Добавляем в список команды; удалим при гибели через OnDie.
                        teamUnits[teamIndex].Add(spawned);
                        int capturedIndex = teamIndex; // захват для лямбды
                        spawned.OnDie += (u, _, _, _) =>
                        {
                            teamUnits[capturedIndex].Remove(u);
                            Debug.Log($"[MatchManager] Юнит погиб: {u.name} (команда {capturedIndex}, player={u.owner}).");
                        };
                        // Разовый AttackMove только если нет активного режима и FormationMarch не используется.
                        if (!cfg.useFormationMarch && currentCommand[teamIndex] == BottomTableAction.None)
                            spawned.AttackMove(attackTarget);
                        try { OnUnitSpawned?.Invoke(teamIndex, spawned); }
                        catch (Exception e) { Debug.LogError($"[MatchManager] OnUnitSpawned: {e.Message}"); }
                    }
                    else
                    {
                        Debug.LogWarning($"[MatchManager] Не удалось заспавнить {entry.unitToSpawn.name} " +
                                         $"для команды {teamIndex} (точка занята или ошибка).");
                    }

                    if (cfg.spawnDelay > 0f) yield return new WaitForSeconds(cfg.spawnDelay);
                }
            }
            Debug.Log($"[MatchManager] Волна команды {teamIndex}: заспавнено {waveUnits.Count} юнитов.");

            // Снимок ФАКТИЧЕСКИ заспавненной волны для «Призыва к Оружию». Обновляем только если что-то
            // создано (пустую/пропущенную волну не запоминаем — прежний снимок остаётся актуальным).
            if (spawnedCounts.Count > 0)
            {
                List<WaveEntry> snapshot = new List<WaveEntry>();
                foreach (KeyValuePair<Unit, int> kv in spawnedCounts)
                    snapshot.Add(new WaveEntry { unitToSpawn = kv.Key, count = kv.Value });
                lastWaveComposition[teamIndex] = snapshot;
            }

            // При спавне волны переотдаём текущую команду ВСЕМ живым юнитам команды (включая новых),
            // чтобы формация перестроилась. Если режим не выбран — новые юниты идут по умолчанию.
            if (currentCommand[teamIndex] == BottomTableAction.Attack)
            {
                SendAttackCommand(teamIndex);
            }
            else if (currentCommand[teamIndex] == BottomTableAction.Defence)
            {
                SendDefenceCommand(teamIndex);
            }
            else if (cfg.useFormationMarch && waveUnits.Count > 0)
            {
                // Режим не выбран — стандартная атака только для юнитов этой волны.
                FormationMarch.Begin(
                    waveUnits, attackTarget, cfg.ownerPlayer,
                    cfg.detectionRadius, cfg.regroupDebounce, cfg.formationPollInterval, cfg.arrivalDistance,
                    cfg.slotSpacing, targetDelegate);
            }
        }

        // ======================== ЭКОНОМИКА ВОЛН: СТОИМОСТЬ И СОСТАВ ========================

        // Стоимость одного префаба по конкретному ресурсу (читается из штатного Unit.resourceCost).
        // 0 — если ресурс в стоимости юнита не указан. Цены живут только в префабе, здесь не дублируются.
        // public — чтобы UI конструктора волны читал цену той же логикой (единый источник).
        public static int PrefabResourceCost(Unit prefab, Resource resource)
        {
            if (prefab == null || resource == null || prefab.resourceCost == null) return 0;
            for (int i = 0; i < prefab.resourceCost.Length; i++)
            {
                ResourceWrapper rw = prefab.resourceCost[i];
                if (rw != null && rw.type == resource) return rw.value;
            }
            return 0;
        }

        // Суммарная стоимость состава волны по ресурсу (с учётом количества каждого типа).
        static int WaveResourceSum(WaveEntry[] composition, Resource resource)
        {
            if (composition == null || resource == null) return 0;
            int sum = 0;
            for (int i = 0; i < composition.Length; i++)
            {
                WaveEntry e = composition[i];
                if (e == null || e.unitToSpawn == null || e.count <= 0) continue;
                sum += PrefabResourceCost(e.unitToSpawn, resource) * e.count;
            }
            return sum;
        }

        /// <summary>
        /// Текущее количество юнитов данного типа в составе волны команды (0, если типа нет).
        /// Единый источник для UI (читается из того же waveComposition, что и спавн).
        /// </summary>
        public int WaveUnitCount(int teamIndex, Unit prefab)
        {
            if (prefab == null) return 0;
            TeamWaveConfig cfg = Team(teamIndex);
            WaveEntry[] comp = cfg != null ? cfg.waveComposition : null;
            if (comp == null) return 0;
            for (int i = 0; i < comp.Length; i++)
                if (comp[i] != null && comp[i].unitToSpawn == prefab) return comp[i].count;
            return 0;
        }

        /// <summary>
        /// Сервер: добавить один юнит указанного типа в состав волны команды (+1 к существующему типу
        /// или новая запись). Отказ, если суммарное лидерство состава превысит пул волны.
        /// Возвращает true при успешном изменении.
        /// </summary>
        public bool TryAddWaveUnit(int teamIndex, Unit prefab)
        {
            if (NetworkConnectionHandler.isClient) return false; // правка состава — только сервер
            if (prefab == null) return false;
            TeamWaveConfig cfg = Team(teamIndex);
            if (cfg == null) return false;

            // Проверка пула: суммарное лидерство с учётом добавляемого юнита.
            int projected = WaveResourceSum(cfg.waveComposition, leadershipResource)
                            + PrefabResourceCost(prefab, leadershipResource);
            if (projected > waveLeadershipPool)
            {
                Debug.Log($"[MatchManager] Команда {teamIndex}: добавление {prefab.name} превысит пул лидерства " +
                          $"({projected} > {waveLeadershipPool}) — отклонено.");
                return false;
            }

            List<WaveEntry> list = new List<WaveEntry>(cfg.waveComposition ?? Array.Empty<WaveEntry>());
            WaveEntry existing = list.Find(e => e != null && e.unitToSpawn == prefab);
            if (existing != null) existing.count++;
            else list.Add(new WaveEntry { unitToSpawn = prefab, count = 1 });
            cfg.waveComposition = list.ToArray();

            OnWaveCompositionChanged?.Invoke(teamIndex);
            BroadcastWaveComposition(teamIndex);
            return true;
        }

        /// <summary>
        /// Сервер: убрать один юнит указанного типа из состава волны команды (−1; при 0 запись удаляется).
        /// Возвращает true при успешном изменении.
        /// </summary>
        public bool TryRemoveWaveUnit(int teamIndex, Unit prefab)
        {
            if (NetworkConnectionHandler.isClient) return false;
            if (prefab == null) return false;
            TeamWaveConfig cfg = Team(teamIndex);
            if (cfg == null || cfg.waveComposition == null) return false;

            List<WaveEntry> list = new List<WaveEntry>(cfg.waveComposition);
            WaveEntry existing = list.Find(e => e != null && e.unitToSpawn == prefab);
            if (existing == null) return false;

            existing.count--;
            if (existing.count <= 0) list.Remove(existing);
            cfg.waveComposition = list.ToArray();

            OnWaveCompositionChanged?.Invoke(teamIndex);
            BroadcastWaveComposition(teamIndex);
            return true;
        }

        /// <summary>
        /// Сервер: текущий состав команды как параллельные массивы (typeID + count) для сетевой рассылки.
        /// Формирование данных — единая точка здесь, в MatchManager.
        /// </summary>
        public void GetWaveCompositionData(int teamIndex, out int[] typeIDs, out int[] counts)
        {
            TeamWaveConfig cfg = Team(teamIndex);
            WaveEntry[] comp = cfg != null ? cfg.waveComposition : null;
            int n = comp != null ? comp.Length : 0;
            typeIDs = new int[n];
            counts  = new int[n];
            for (int i = 0; i < n; i++)
            {
                WaveEntry e = comp[i];
                typeIDs[i] = (e != null && e.unitToSpawn != null) ? e.unitToSpawn.unitTypeID : 0;
                counts[i]  = (e != null) ? e.count : 0;
            }
        }

        /// <summary>
        /// Клиент: применить присланный сервером состав волны команды. Пишем прямо в waveComposition —
        /// это единый источник, который читает UI конструктора (на сервере и на клиенте одинаково).
        /// Префабы резолвятся штатно через GameManager.gameUnits по typeID. На сервере не вызывается.
        /// </summary>
        public void ApplyWaveComposition(int teamIndex, int[] typeIDs, int[] counts)
        {
            TeamWaveConfig cfg = Team(teamIndex);
            if (cfg == null || typeIDs == null || counts == null) return;

            List<WaveEntry> list = new List<WaveEntry>();
            int n = Mathf.Min(typeIDs.Length, counts.Length);
            for (int i = 0; i < n; i++)
            {
                if (counts[i] <= 0) continue;
                if (GameManager.instance != null &&
                    GameManager.instance.gameUnits.TryGetValue(typeIDs[i], out Unit prefab) && prefab != null)
                    list.Add(new WaveEntry { unitToSpawn = prefab, count = counts[i] });
            }
            cfg.waveComposition = list.ToArray();

            OnWaveCompositionChanged?.Invoke(teamIndex);
        }

        // Сервер: разослать актуальный состав команды клиентам после каждого изменения.
        // Единая точка вызова (из Try*WaveUnit). Сам RPC — NetworkDataSync.WaveComposition.cs.
        void BroadcastWaveComposition(int teamIndex)
        {
            if (NetworkDataSync.instance == null) return;
            GetWaveCompositionData(teamIndex, out int[] typeIDs, out int[] counts);
            NetworkDataSync.instance.WaveCompositionSend(teamIndex, typeIDs, counts);
        }

        // ======================== ОТСТРОЙКА БАШЕН ========================

        // Текущие подписки: башня → конфиг её точки. По событию OnDie находим точку.
        readonly Dictionary<Unit, PointTowerConfig> hookedTowers = new Dictionary<Unit, PointTowerConfig>();

        // Подписка на смерть башни конкретной точки.
        void HookTower(Unit tower, PointTowerConfig cfg)
        {
            Debug.Log($"[MatchManager] Подписка на смерть башни {tower.name}.");
            if (tower == null || cfg == null) return;
            hookedTowers[tower] = cfg;
            tower.OnDie += HandleTowerDie;
        }

        // Башня погибла → точка переходит сопернику, тело снимается, через задержку отстраивается новая.
        void HandleTowerDie(Unit unit, int playerThatKills, Unit unitThatKills, bool rewards)
        {
            Debug.Log($"[MatchManager] УНИЧТОЖЕНА БАШНЯ: {unit.name} (owner={unit.owner}, " +
                      $"убийца player={playerThatKills}, юнит={( unitThatKills != null ? unitThatKills.name : "null" )}).");
            unit.OnDie -= HandleTowerDie;
            if (!hookedTowers.TryGetValue(unit, out PointTowerConfig cfg)) return;
            hookedTowers.Remove(unit);

            PointOfInterest poi = cfg.point;
            if (poi == null) return;

            // Команда захвата = соперник текущего владельца. Для нейтральной точки (центр на старте)
            // соперника нет → штатная атрибуция убийцы (playerThatKills → unitThatKills.team).
            int newTeam = ResolveCaptureTeam(poi.CurrentTeam, playerThatKills, unitThatKills);

            // Сразу меняем владельца и снимаем башню (тело уничтожит штатный OnDie ассета).
            Debug.Log($"[MatchManager] Точка {poi.name} захвачена: команда {poi.CurrentTeam} → {newTeam}.");
            poi.SetTeam(newTeam);
            poi.ClearTower();

            // Диагностика: что возвращает таргетинг сразу после захвата.
            if (lane != null)
            {
                int attackerTeam = newTeam;
                Debug.Log($"[MatchManager] ЗАХВАТ {poi.name} (ID={poi.GetInstanceID()}): " +
                          $"towerAlive={poi.TowerAlive}, currentTeam={poi.CurrentTeam}. " +
                          $"NextAttackTarget(team={attackerTeam}) = {lane.NextAttackTarget(attackerTeam)}");
                Debug.Log($"[MatchManager] Lane-точки для team={attackerTeam}: " +
                          string.Join(", ", lane.DebugPoints(attackerTeam)));
            }

            // Серверо-авторитетно: разослать новое владение клиентам (только живой захват, без позднего входа).
            BroadcastPointTeam(poi, newTeam);

            // Фронт сместился — обновить хранимые точки и переотдать текущие команды обеим командам.
            RefreshTargetPoints();

            // Итоговые цели после захвата (для отладки).
            for (int i = 0; i < 2; i++)
            {
                TeamWaveConfig cfg2 = Team(i);
                if (cfg2 == null) continue;
                int player = cfg2.ownerPlayer;
                Debug.Log($"[MatchManager] Следующие цели команды {i}: " +
                          $"атака={POIName(AttackTargetPOI(player))}, " +
                          $"защита={POIName(DefenceTargetPOI(player))}.");
            }

            for (int i = 0; i < 2; i++)
            {
                if (currentCommand[i] == BottomTableAction.Attack)        SendAttackCommand(i);
                else if (currentCommand[i] == BottomTableAction.Defence)  SendDefenceCommand(i);
            }

            // Призванные из отдельного списка (не слушающие общих приказов) переотдают свою команду
            // (Защита → новая передовая своя точка, Атака → новая вражеская). Слушающие общие — уже в teamUnits
            // и покрыты переотдачей команд выше.
            ReissueSummonedCommand();

            // towerPrefab == null → только захват точки без отстройки (штатно для Defence-точек).
            if (cfg.towerPrefab == null) return;

            int capturePlayer = FindPlayerByTeam(newTeam);
            if (capturePlayer < 0) capturePlayer = unit.owner;

            Debug.Log($"[MatchManager] Запускаем отстройку башни для точки {cfg.point.name} " +
                      $"(player={capturePlayer}, задержка={cfg.rebuildDelay} сек).");
            StartCoroutine(RebuildTower(cfg, unit.transform.position, unit.transform.eulerAngles.y, capturePlayer));
        }

        IEnumerator RebuildTower(PointTowerConfig cfg, Vector3 position, float rotationY, int player)
        {
            if (cfg.rebuildDelay > 0f) yield return new WaitForSeconds(cfg.rebuildDelay);

            // Проверка ПОСЛЕ задержки: если в towerPrefab назначен объект сцены, ассет мог уничтожить
            // его телом погибшей башни за время ожидания (отложенный Destroy) → Instantiate упадёт.
            // Unity-объект после Destroy сравнивается с null. Нужен именно префаб-ассет, не объект сцены.
            if (cfg.towerPrefab == null)
            {
                Debug.LogError($"[MatchManager] towerPrefab для точки {cfg.point.name} не задан или уничтожен — " +
                               "в поле должен быть ПРЕФАБ-АССЕТ башни, а не объект сцены. Отстройка отменена.");
                yield break;
            }

            Unit tower = Unit.Spawn(cfg.towerPrefab, position, rotationY, player);
            if (tower == null)
            {
                Debug.LogError($"[MatchManager] Не удалось заспавнить башню для точки {cfg.point.name} (точка занята?).");
                yield break;
            }

            Debug.Log($"[MatchManager] Башня отстроена: {tower.name} для точки {cfg.point.name} " +
                      $"(player={tower.owner}, netID={tower.netID}).");
            cfg.point.SetTower(tower);
            HookTower(tower, cfg);
        }

        // Соперник текущего владельца (модель 2 команд). Нейтральный/неизвестный владелец → атрибуция убийцы.
        int ResolveCaptureTeam(int currentTeam, int playerThatKills, Unit unitThatKills)
        {
            int opponent = OpponentTeam(currentTeam);
            if (opponent >= 0) return opponent;

            int[] teams = SlotManager.instance.playerTeam;
            if (playerThatKills >= 0 && playerThatKills < teams.Length) return teams[playerThatKills];
            if (unitThatKills != null) return unitThatKills.team;
            return currentTeam;
        }

        // Команда-соперник среди двух участников матча (teamA/teamB). -1, если соперника нет
        // (владелец нейтрален или не входит в участников).
        int OpponentTeam(int team)
        {
            if (team < 0) return -1;
            int[] pt = SlotManager.instance.playerTeam;
            int tA = (teamA != null && teamA.ownerPlayer >= 0 && teamA.ownerPlayer < pt.Length) ? pt[teamA.ownerPlayer] : -1;
            int tB = (teamB != null && teamB.ownerPlayer >= 0 && teamB.ownerPlayer < pt.Length) ? pt[teamB.ownerPlayer] : -1;
            if (team == tA && tB >= 0) return tB;
            if (team == tB && tA >= 0) return tA;
            return -1;
        }

        static int FindPlayerByTeam(int team)
        {
            int[] teams = SlotManager.instance.playerTeam;
            for (int i = 0; i < teams.Length; i++)
                if (teams[i] == team) return i;
            return -1;
        }

        // ======================== СЕТЕВАЯ СИНХРОНИЗАЦИЯ ВЛАДЕНИЯ ========================

        // Сервер: разослать клиентам нового владельца точки (по индексу в Lane).
        void BroadcastPointTeam(PointOfInterest poi, int team)
        {
            if (lane == null || NetworkDataSync.instance == null) return;
            int index = lane.IndexOf(poi);
            if (index < 0) return;
            NetworkDataSync.instance.PointTeamSend(index, team);
        }

        /// <summary>Клиент: применить владельца точки по индексу (приходит сетевым RPC). Единый вход для Lane.</summary>
        public void ApplyPointTeam(int index, int team)
        {
            if (lane != null) lane.SetPointTeam(index, team);
        }

        // ======================== ПРОВЕРКИ ========================

        void ValidateSetup()
        {
            if (teamA == null || teamA.spawnPoint == null || teamB == null || teamB.spawnPoint == null)
                Debug.LogWarning("[MatchManager] Не настроены spawnPoint обеих команд.");

            if (lane == null)
                Debug.LogWarning("[MatchManager] Lane не назначена — волны/команды пойдут на статичные targetPoint.");

            if (goldResource == null || leadershipResource == null)
                Debug.LogWarning("[MatchManager] Не назначены ссылки на ресурсы экономики волн " +
                                 "(goldResource/leadershipResource) — проверки капа и списание золота будут пропущены.");

            if (rebuildablePoints != null)
            {
                foreach (PointTowerConfig cfg in rebuildablePoints)
                {
                    if (cfg == null || cfg.point == null)
                    {
                        Debug.LogWarning("[MatchManager] В rebuildablePoints есть пустой элемент или не назначена точка.");
                        continue;
                    }
                    if (cfg.point.type == PointOfInterest.PointType.Castle)
                        Debug.LogWarning($"[MatchManager] Точка {cfg.point.name} — замок (Castle). Замки не перестраиваются, уберите её из rebuildablePoints.");
                    if (cfg.towerPrefab == null)
                        Debug.Log($"[MatchManager] Точка {cfg.point.name}: towerPrefab не назначен — захват без отстройки (OK для Defence-точек).");
                    if (cfg.point.unitRef == null)
                        Debug.LogWarning($"[MatchManager] Точка {cfg.point.name}: unitRef не задан — стартовая башня не найдена, захват не отследится.");
                }
            }

            // Победа — штатная (GameManager.specificUnitsDead). Менеджер её не реализует.
            if (GameManager.instance != null &&
                (GameManager.instance.specificUnitsDead == null || GameManager.instance.specificUnitsDead.Length == 0))
                Debug.LogWarning("[MatchManager] GameManager.specificUnitsDead не настроен — " +
                                 "победа по уничтожению базы не сработает. Задайте NetID баз и winningTeam в Inspector у GameManager.");
        }
    }
}
